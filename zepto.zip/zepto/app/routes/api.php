<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PopupController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware(['auth.shopify'])->group(function () {

    Route::get('/dashboard', [DashboardController::class, 'dashboard']);
    Route::get('/analytics', [DashboardController::class, 'analytics']);

    // Routes for popups
    Route::get('popups', [PopupController::class, 'index']);
    Route::get('popups/{popup_type}', [PopupController::class, 'show']);
    Route::put('popups/{popup_type}', [PopupController::class, 'update']);
    Route::put('popups/{popup_type}/status-toggle', [PopupController::class, 'statusToggle']);
});
