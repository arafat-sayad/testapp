<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('uid', 32)->unique();
            $table->bigInteger('shopify_id')->unsigned();
            $table->bigInteger('shop_id')->unsigned();
            $table->string('name', 20);
            $table->bigInteger('customer_id')->unsigned();
            $table->bigInteger('customer_shopify_id')->unsigned();
            $table->boolean('confirmed')->default(false);
            $table->double('total_price')->default(0);
            $table->double('total_price_usd')->default(0);
            $table->timestamps();

            // Indexes
            $table->index('shopify_id');
            $table->index('shop_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
