<?php

use App\Enums\ProductStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('uid', 32)->unique();
            $table->bigInteger('shopify_id')->unsigned();
            $table->bigInteger('shop_id')->unsigned();
            $table->string('title', 250);
            $table->string('handle', 250);
            $table->string('url', 1000)->nullable();
            $table->string('image_url', 1000)->nullable();
            $table->integer('order_count')->default(0);
            $table->enum('status', ProductStatus::values())->default(ProductStatus::ACTIVE->value);
            $table->timestamp('published_at')->nullable();
            $table->timestamps();

            // Indexes
            $table->index('shopify_id');
            $table->index('shop_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
