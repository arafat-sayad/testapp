<?php

use App\Enums\CustomerStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->string('uid', 32)->unique();
            $table->bigInteger('shopify_id')->unsigned();
            $table->bigInteger('shop_id')->unsigned();
            $table->string('first_name', 60);
            $table->string('last_name', 60)->nullable();
            $table->string('email', 100)->nullable();
            $table->string('country', 50)->nullable();
            $table->enum('status', CustomerStatus::values())->default(CustomerStatus::ACTIVE->value);
            $table->boolean('email_subscription')->default(true);
            $table->timestamps();

            // Indexes
            $table->index('shopify_id');
            $table->index('shop_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customers');
    }
};
