<?php

namespace App\Models;

use App\Enums\Popup\PopupType;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Popup extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'settings' => 'json',
    ];


    /**
     * @return void
     */
    protected static function booted()
    {
        static::creating(function ($popup) {
            $popup->uid = str_unique();
        });
    }

    public function getSettingsDataAttribute(): array
    {
        $settingsSchema = config('popup.' . $this->popup_type, []);
        return array_replace_recursive($settingsSchema, $this->settings ?? []);
    }


    public function scopeShopPopup($model, PopupType $popupType = null): Builder
    {
        return $model->when($popupType, function ($query) use ($popupType) {
            $query->where('popup_type', $popupType->value);
        })->where('shop_id', shop()->id);
    }

    public function popupLogs()
    {
        return $this->hasMany(PopupLog::class);
    }
}
