<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class PopupLog extends Model
{
    use HasFactory;

    public function shop()
    {
        return $this->belongsTo(Shop::class);
    }

    public function popup()
    {
        return $this->belongsTo(Popup::class);
    }

    public function scopeRange(Builder $builder, $filter = [])
    {
        $from = isset($filter['from']) ? Carbon::parse($filter['from']) : Carbon::now()->subDays(6);
        $to = isset($filter['to']) ? Carbon::parse($filter['to']) : Carbon::now();
        $from = $from->startOfDay();
        $to = $to->endOfDay();
        $builder->whereBetween('created_at', [$from, $to]);
    }
}
