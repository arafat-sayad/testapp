<?php

declare(strict_types=1);

use App\Enums\Popup\PopupType;
use Carbon\Carbon;
use App\Models\Shop;
use App\Utilities\ApiJsonResponse;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Support\Str;

if (!function_exists('shop')) {

    /**
     * @param $guard
     * @return Shop|null
     */
    function shop($guard = null): ?Shop
    {
        /**
         * @var Shop $shop
         */
        $shop = auth($guard)->user();

        return $shop;
    }
}


if (!function_exists('carbon')) {
    /**
     * @param string|null $date
     * @param string $timezone
     * @return Carbon
     */
    function carbon(string $date = null, string $timezone = 'UTC'): Carbon
    {
        if (!$date) {
            return Carbon::now($timezone);
        }

        return (new Carbon($date, $timezone));
    }
}

if (!function_exists('str_unique')) {
    /**
     * @param int $length
     * @return string
     */
    function str_unique(int $length = 16): string
    {
        $side = rand(0, 1); // 0 = left, 1 = right
        $salt = rand(0, 9);
        $len = $length - 1;
        $string = Str::random($len <= 0 ? 7 : $len);

        $separatorPos = (int) ceil($length / 4);

        $string = $side === 0 ? ($salt . $string) : ($string . $salt);
        $string = substr_replace($string, '-', $separatorPos, 0);

        return substr_replace($string, '-', negative_value($separatorPos), 0);
    }
}



if (!function_exists('negative_value')) {
    /**
     * @param int|float $value
     * @param bool $float
     * @return int|float
     */
    function negative_value(int|float $value, bool $float = false): int|float
    {
        if ($float) {
            $value = (float) $value;
        }

        return 0 - abs($value);
    }
}


if (!function_exists('api')) {
    /**
     * @param array|Arrayable|string|null $data
     * @return ApiJsonResponse
     */
    function api(array|Arrayable|string|null $data = []): ApiJsonResponse
    {
        return new ApiJsonResponse($data);
    }
}

if (!function_exists('recursive_merge')) {
    /**
     * @param array $array1
     * @param array $array2
     * @return array
     */
    function recursive_merge(array $array1, array $array2): array
    {
        foreach ($array2 as $key => $value) {
            if (is_array($value) && isset($array1[$key]) && is_array($array1[$key])) {
                $array1[$key] = recursive_merge($array1[$key], $value);
            } else {
                $array1[$key] = $value;
            }
        }
        return $array1;
    }
}

if (!function_exists('extractKeysWithValue')) {
    /**
     * @param array $array
     * @return array
     */
    function extractKeysWithValue($array)
    {
        $result = [];
        foreach ($array as $key => $value) {
            if (!empty($value)) {
                if (is_array($value)) {
                    $nestedKeys = extractKeysWithValue($value);
                    if (!empty($nestedKeys)) {
                        $result[$key] = $nestedKeys;
                    }
                } else {
                    $result[$key] = $value;
                }
            }
        }
        return $result;
    }
}



if (!function_exists('popupSettingsMerge')) {
    /**
     * @param string $str
     * @return array
     */
    function popupSettingMerge(PopupType $popupType, array $array): array
    {
        return recursive_merge(config('popup.' . $popupType->value), $array);
    }
}

