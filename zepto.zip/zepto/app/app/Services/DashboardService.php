<?php

namespace App\Services;

use App\Models\Popup;
use App\Models\PopupLog;
use Illuminate\Support\Facades\DB;

class DashboardService extends BaseService
{
    public function getDashboardData(): array
    {
        $popups = Popup::with(['popupLogs' => function ($query) {
            return $query->select(
                'popup_id',
                'log_type',
                DB::raw("(count(popup_logs.id)) as total_logs"),
            )
                ->range()
                ->groupBy('popup_id', 'log_type');
        }])->where('shop_id', shop()->id)
            ->select('id', 'popup_type', 'status', 'status_toggle_at')
            ->get();

        return $popups->map(function ($popup) {
            return [
                'id' => $popup->id,
                'popup_type' => $popup->popup_type,
                'status' => $popup->status,
                'status_toggle_at' => $popup->status_toggle_at,
                'popup_logs' => $popup->popupLogs->pluck('total_logs', 'log_type')->toArray()
            ];
        })->toArray();
    }

    public function getAnalyticsData($filter = []): array
    {
        $logsCount = PopupLog::where('shop_id', shop()->id)
            ->select(
                'log_type',
                DB::raw('COUNT(id) as total_logs')
            )
            ->groupBy('log_type')
            ->orderBy('log_type')
            ->get()
            ->pluck('total_logs', 'log_type');

        $popupLogs = PopupLog::where('shop_id', shop()->id)
            ->range($filter)
            ->select(
                'log_type',
                DB::raw('COUNT(id) as total_logs'),
                DB::raw('DATE(created_at) as created_date')
            )
            ->groupBy('created_date', 'log_type')
            ->orderBy('created_date')
            ->get();

        $formattedLogs = $popupLogs->groupBy('created_date')->map(function ($logs) {
            return $logs->pluck('total_logs', 'log_type');
        });

        return [
            'count' => $logsCount,
            'analytics' => $formattedLogs
        ];
    }
}
