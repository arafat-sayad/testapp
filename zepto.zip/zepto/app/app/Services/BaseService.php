<?php

namespace App\Services;

abstract class BaseService
{
    //
}
