<?php

namespace App\Services;

use App\Enums\Popup\PopupStatus;
use App\Enums\Popup\PopupType;
use App\Models\Popup;
use App\Models\Shop;
use Illuminate\Database\Eloquent\Collection;

class PopupService extends BaseService
{

    public function index()
    {
        $popups = Popup::shopPopup()->select(['uid', 'shop_id', 'popup_type', 'status'])->get();
        return $this->mergeDefaultPopupList($popups);
    }

    public function getShopPopup(Shop $shop, PopupType $popupType): Popup
    {
        $popup = Popup::shopPopup($popupType)->first();

        if (!$popup) {
            $popup = $this->createPopup($shop, $popupType, PopupStatus::INACTIVE);
        }

        return $popup;
    }

    public function statusToggle(PopupStatus $status, PopupType $popupType): bool
    {
        $popup = Popup::shopPopup($popupType)->first();

        if (!$popup) {
            $this->createPopup(shop(), $popupType, $status);
            return true;
        }

        $popup->status = $status->value;
        $popup->save();
        return true;
    }


    public function settingsUpdate(array $settings, PopupType $popupType)
    {
        $popup =  Popup::shopPopup($popupType)->first();

        // TODO:: array_replace_recursive not working as expected. Have to check that.
        $popup->settings = array_replace_recursive($popup->settings, $settings);
        $popup->save();
        return $this->getShopPopup(shop(), $popupType);
    }

    private function createPopup(Shop $shop, PopupType $popupType, PopupStatus $status): Popup
    {
        $popup = new Popup();
        $popup->fill([
            'shop_id' => $shop->id,
            'popup_type' => $popupType->value,
            'status' => $status->value,
            'settings' => [],
        ]);

        $popup->save();
        return $popup;
    }

    private function mergeDefaultPopupList(Collection $popups): array
    {

        $popupTypes = PopupType::values();

        $default = [];

        foreach ($popupTypes as $popupType) {
            $default[] = [
                'shop_id' => shop()->id,
                'status' => PopupStatus::INACTIVE->value,
                'popup_type' => $popupType
            ];
        }

        $filteredPopups = $popups->map(function ($popup) {
            return $popup->only('shop_id', 'popup_type', 'status');
        });

        return array_replace_recursive($default, $filteredPopups->toArray());
    }
}
