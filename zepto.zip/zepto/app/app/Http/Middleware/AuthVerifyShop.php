<?php

namespace App\Http\Middleware;

use App\Exceptions\UnauthorizedException;
use App\Models\Shop;
use Closure;
use Illuminate\Encryption\Encrypter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Osiset\ShopifyApp\Http\Middleware\VerifyShopify;
use Symfony\Component\HttpFoundation\Response;

class AuthVerifyShop
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse|Response
     */
    public function handle(Request $request, Closure $next, $guard = 'shop')
    {
        if (app()->environment() === 'local') {

            $token = $request->bearerToken();
            if (empty($token)) {
                throw new UnauthorizedException();
            }

            $shopId = base64_decode($token);

            $shop = Shop::where('name', $shopId)->where('password', '!=', '')->first();

            if ($shop == null) {
                throw new UnauthorizedException();
            }

            auth($guard)->setUser($shop);

            return $next($request);
        }

        $shop = null;

        if (app()->environment() === 'production' && $request->hasHeader('X-Prod-Token-Key')) {
            $shop = $this->debugProd($request);
        }

        if (app()->environment() !== 'production' && $request->header('X-Test-Mode', 'false') === 'true') {
            $token = $request->bearerToken();
            if (empty($token)) {
                throw new UnauthorizedException();
            }

            $shopId = base64_decode($token);
            $shop = Shop::where('name', $shopId)->where('password', '!=', '')->first();
        }

        if ($shop) {
            auth($guard)->setUser($shop);

            return $next($request);
        }

        /**
         * @var VerifyShopify $verifyShopifyMiddleware
         */
        $verifyShopifyMiddleware = app(VerifyShopify::class);
        return $verifyShopifyMiddleware->handle($request, $next);
    }

    protected function debugProd(Request $request): ?Shop
    {
        $token = $request->bearerToken();
        if (empty($token)) {
            throw new UnauthorizedException();
        }

        $payloadString = Crypt::decryptString($token);
        $payload = json_decode($payloadString, true);

        if (carbon()->gte(carbon($payload['exp']))) {
            throw new UnauthorizedException('Token has been expired!');
        }

        if (app()->environment() !== $payload['env']) {
            throw new UnauthorizedException('This token is invalid, not matched with the current env!');
        }

        if ($payload['key'] !== $request->header('X-Prod-Token-Key')) {
            throw new UnauthorizedException('Your given salt did not match with the token!');
        }

        return Shop::where('uid', $payload['id'])->first();
    }
}
