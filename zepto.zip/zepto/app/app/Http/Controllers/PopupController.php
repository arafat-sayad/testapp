<?php

namespace App\Http\Controllers;

use App\Enums\Popup\PopupStatus;
use App\Enums\Popup\PopupType;
use App\Http\Requests\Popup\PopupUpdateRequest;
use App\Http\Requests\Popup\StatusToggleRequest;
use App\Services\PopupService;
use Illuminate\Http\Request;

class PopupController extends Controller
{
    public function __construct(protected PopupService $popupService)
    {
        //
    }

    public function index()
    {
        return api(['popups' => $this->popupService->index()])->success('Popup list fetched successfully!');
    }

    public function show($popupType)
    {
        $popup = $this->popupService->getShopPopup(shop(), PopupType::tryFrom($popupType));
        return api(['popup' => $popup->only('uid', 'shop_id', 'popup_type', 'status', 'settings_data')])->success('Popup details fetched successfully!');
    }

    public function update(PopupUpdateRequest $request, $popupType)
    {
        $popup = $this->popupService->settingsUpdate($request->settings, PopupType::tryFrom($popupType));
        return api($popup->only('uid', 'shop_id', 'popup_type', 'status', 'settings_data'))->success('Popup settings updated successfully!');
    }

    public function statusToggle(StatusToggleRequest $request, $popupType)
    {
        $this->popupService->statusToggle(PopupStatus::tryFrom($request->status), PopupType::tryFrom($popupType));
        return api()->success('Popup status updated successfully!');
    }
}
