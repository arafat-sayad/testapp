<?php

namespace App\Http\Controllers;

use App\Services\DashboardService;
use Illuminate\Http\Request;

class DashboardController extends Controller
{

    public function __construct(protected DashboardService $dashboardService)
    {
        //
    }

    public function dashboard()
    {
        $popups = $this->dashboardService->getDashboardData();
        return api(['popups' => $popups])->success('Dashboard data fetched successfully!');
    }

    public function analytics(Request $request)
    {
        $analytics = $this->dashboardService->getAnalyticsData($request->only('from', 'to'));
        return api($analytics)->success('Analytics data fetched successfully!');
    }
}
