<?php

namespace App\Enums;

enum TranslationStatus: int
{
    use EnumTrait;

    case ACTIVE = 1;

    case INACTIVE = 0;
}
