<?php

namespace App\Enums;

enum Template: int
{
    use EnumTrait;

    case ONE = 1;

    case TWO = 2;

    case THREE = 3;

    case FOUR = 4;

    case FIVE = 5;
}
