<?php

namespace App\Enums;

enum Color: string
{
    use EnumTrait;

    case PRIMARY = "#391363";

    case WHITE = "#FFFFFF";

    case DARK = "#404040";

    case RED = "#E03E1A";

    case YELLOW = "#F79722";

    case PURPLE = "#8A38F5";

    case SKY_BLUE = "#0C8CE9";
}
