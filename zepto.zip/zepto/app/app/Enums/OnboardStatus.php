<?php

namespace App\Enums;

enum OnboardStatus: int
{
    use EnumTrait;

    case INCOMPLETE = 0;
    
    case COMPLETE = 1;
}
