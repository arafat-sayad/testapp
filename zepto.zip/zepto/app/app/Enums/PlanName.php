<?php

namespace App\Enums;

enum PlanName: string
{
    use EnumTrait;

    case FREE = 'free';

    case STANDARD = 'standard';

    case GROWTH = 'growth';

    case ADVANCED = 'advanced';

    case POWER = 'power';

}
