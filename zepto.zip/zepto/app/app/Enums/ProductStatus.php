<?php

namespace App\Enums;

enum ProductStatus: string
{
    use EnumTrait;

    case ACTIVE = 'active';

    case INACTIVE = 'inactive';
}
