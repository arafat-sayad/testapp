<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum PopupLogType: int
{
    use EnumTrait;

    case VISITOR = 1;

    case IMPRESSION = 2;

    case ENGAGEMENT = 3;
}
