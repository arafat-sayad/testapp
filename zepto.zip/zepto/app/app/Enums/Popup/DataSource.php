<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum DataSource: string
{
    use EnumTrait;

    case ACTUAL = "actual";

    case MANUAL = "manual";
}
