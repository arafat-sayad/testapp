<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum DisplayPositionDesktop: int
{
    use EnumTrait;

    case BOTTOM_LEFT = 1;

    case BOTTOM_RIGHT = 2;

    case TOP_LEFT = 3;

    case TOP_RIGHT = 4;
}
