<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum PopupStatus: int
{
    use EnumTrait;

    case ACTIVE = 1;

    case INACTIVE = 0;
}
