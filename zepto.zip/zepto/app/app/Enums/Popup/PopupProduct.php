<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum PopupProduct: int
{
    use EnumTrait;

    case All = 1;

    case INCLUDE = 2;

    case EXCLUDE = 3;
}
