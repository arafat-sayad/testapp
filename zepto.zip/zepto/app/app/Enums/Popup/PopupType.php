<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum PopupType: string
{
    use EnumTrait;

    case SALE_POPUP = 'sale_popup';

    case SOLD_COUNT = 'sold_count';
    
    case VISITOR_COUNT = 'visitor_count';
}
