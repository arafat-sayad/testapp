<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum LookbackFormat: int
{
    use EnumTrait;

    case MINUTES = 1;

    case HOURS = 2;

    case DAYS = 3;
}
