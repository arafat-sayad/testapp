<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum DisplayPage: int
{
    use EnumTrait;

    case All_PAGE = 1;

    case HOME_PAGE = 2;

    case FOLLOWING_URL = 3;

    case ONLY_PAGE = 4;

    case EXCLUDE_PAGE = 5;
}
