<?php

namespace App\Enums\Popup;

use App\Enums\EnumTrait;

enum DisplayPositionMobile: int
{
    use EnumTrait;

    case BOTTOM = 1;

    case TOP = 2;
}
