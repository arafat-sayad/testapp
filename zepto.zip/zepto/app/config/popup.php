<?php

use App\Enums\Color;
use App\Enums\Popup\DataSource;
use App\Enums\Popup\DisplayPage;
use App\Enums\Popup\DisplayPositionDesktop;
use App\Enums\Popup\DisplayPositionMobile;
use App\Enums\Popup\LookbackFormat;
use App\Enums\Popup\PopupType;
use App\Enums\Popup\PopupProduct;
use App\Enums\Template;

$display = [
    "before_showing_time" => 10,
    "after_showing_time" => 10,
    "display_page" => [
        "page" => DisplayPage::ONLY_PAGE->value,
        "urls" => []
    ],
    "position" => [
        "desktop" => [
            "place" => DisplayPositionDesktop::BOTTOM_LEFT->value
        ],
        "mobile" => [
            "enable" => true,
            "place" => DisplayPositionMobile::BOTTOM->value
        ]
    ]
];

$styles = [
    "colors" => [
        "bg" => Color::WHITE->value,
        "text" => Color::DARK->value,
        "time" => Color::PRIMARY->value,
        "action" => Color::PRIMARY->value,
    ],
    "template" => Template::ONE->value,
];


return [

    PopupType::SALE_POPUP->value => [
        "message" => "",
        "data_source" => DataSource::ACTUAL->value,
        "fallback" => [
            "customer" => [],
            "location" => []
        ],
        "lookback_time" => [
            "limit" => 30,
            "format" => LookbackFormat::DAYS->value
        ],
        "product" => [
            "type" => PopupProduct::All->value,
            "ids" => []
        ],
        "call_to_action_text" => "Buy Now",
        "display" => $display,
        "styles" => $styles
    ],
    PopupType::VISITOR_COUNT->value => [
        "message" => "",
        "data_source" => DataSource::ACTUAL->value,
        DataSource::ACTUAL->value => [
            "hide_if_visitor" => 10,
        ],
        DataSource::MANUAL->value => [
            "min" => 20,
            "max" => 30,
        ],
        "popup_manager_branding" => false,
        "display" => $display,
        "styles" => $styles
    ],
    PopupType::SOLD_COUNT->value => [
        "message" => "",
        "data_source" => DataSource::ACTUAL->value,
        DataSource::ACTUAL->value => [
            "hide_if_visitor" => 10,
        ],
        DataSource::MANUAL->value => [
            "min" => 20,
            "max" => 30,
        ],
        "lookback_time" => [
            "limit" => 30,
            "format" => LookbackFormat::DAYS->value
        ],
        "call_to_action_text" => "Buy Now",
        "display" => $display,
        "styles" => $styles
    ],
];
