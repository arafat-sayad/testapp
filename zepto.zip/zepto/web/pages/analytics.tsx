import { TitleBar } from '@shopify/app-bridge-react';
import { Page } from '@shopify/polaris';

import Analytics from '@components/view/Analytics';
import '../styles/globals.css';

const AnalyticsPage = () => {
  return (
    <Page>
      <TitleBar title="Analytics" />
      <Analytics />
    </Page>
  );
};

export default AnalyticsPage;
