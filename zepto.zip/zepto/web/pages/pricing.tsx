import Pricing from '@components/view/Pricing';

const PricingPage = () => {
  return <Pricing />;
};

export default PricingPage;
