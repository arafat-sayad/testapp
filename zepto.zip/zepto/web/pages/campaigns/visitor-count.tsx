import VisitorCount from '@components/view/VisitorCount';
import { TitleBar } from '@shopify/app-bridge-react';
import { Page } from '@shopify/polaris';

const VisitorCountPage = () => {
  return (
    <Page>
      <TitleBar
        title="Visitor Count"
        breadcrumbs={[
          {
            content: 'Campaigns',
            url: '/campaigns',
          },
        ]}
        primaryAction={{
          content: 'Save Changes',
          onAction: () => console.log('save'),
        }}
        secondaryActions={[
          {
            content: 'Discard',
            onAction: () => console.log('cancel'),
          },
        ]}
      />
      <VisitorCount />
    </Page>
  );
};

export default VisitorCountPage;
