import SalesPop from '@components/view/SalesPop';
import { TitleBar } from '@shopify/app-bridge-react';
import { Page } from '@shopify/polaris';

const SalesPopPage = () => {
  return (
    <Page>
      <TitleBar
        title="Sales Pop"
        breadcrumbs={[
          {
            content: 'Campaigns',
            url: '/campaigns',
          },
        ]}
        primaryAction={{
          content: 'Save Changes',
          onAction: () => console.log('save'),
        }}
        secondaryActions={[
          {
            content: 'Discard',
            onAction: () => console.log('cancel'),
          },
        ]}
      />
      <SalesPop />
    </Page>
  );
};

export default SalesPopPage;
