import SoldCount from '@components/view/SoldCount';
import { TitleBar } from '@shopify/app-bridge-react';
import { Page } from '@shopify/polaris';

const SoldCountPage = () => {
  return (
    <Page>
      <TitleBar
        title="Sold Count"
        breadcrumbs={[
          {
            content: 'Campaigns',
            url: '/campaigns',
          },
        ]}
        primaryAction={{
          content: 'Save Changes',
          onAction: () => console.log('save'),
        }}
        secondaryActions={[
          {
            content: 'Discard',
            onAction: () => console.log('cancel'),
          },
        ]}
      />
      <SoldCount />
    </Page>
  );
};

export default SoldCountPage;
