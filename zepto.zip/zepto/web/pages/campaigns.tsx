import Campaign from '@components/view/Campaign';
import { TitleBar } from '@shopify/app-bridge-react';
import { Page } from '@shopify/polaris';

const CampaignPage = () => {
  return (
    <Page>
      <TitleBar title="Campaigns" />
      <Campaign />
    </Page>
  );
};

export default CampaignPage;
