import Translation from '@components/view/Translation';
import { Modal, TitleBar } from '@shopify/app-bridge-react';
import { Page } from '@shopify/polaris';
import { useState } from 'react';

const TranslationPage = () => {
  const [openModal, setOpenModal] = useState(false);
  const handleClose = () => {
    setOpenModal(false);
  };

  return (
    <Page>
      <TitleBar
        title="Translation"
        primaryAction={{
          content: 'Save Changes',
          onAction: () => console.log('save'),
        }}
        secondaryActions={[
          {
            content: 'Discard',
            onAction: () => console.log('cancel'),
          },
        ]}
      />
      <Modal
        title="Changes you have made may not be saved"
        message="Your Content Box translation appears incomplete. Please ensure that Variables are properly set before saving these changes."
        open={openModal}
        primaryAction={{
          destructive: true,
          content: 'Discard Changes',
          onAction: handleClose,
        }}
        secondaryActions={[
          {
            content: 'Keep Editing',
            onAction: handleClose,
          },
        ]}
      />

      <Translation />
    </Page>
  );
};

export default TranslationPage;
