import { NavigationMenu } from '@shopify/app-bridge-react';
import '@shopify/polaris/build/esm/styles.css';
import { BrowserRouter } from 'react-router-dom';
import Routes from './Routes';
import {
  AppBridgeProvider,
  PolarisProvider,
  QueryProvider,
} from './components';
import { ToastProvider } from './context/ToastContext';
import './styles/globals.css';

export default function App() {
  // Any .tsx or .jsx files in /pages will become a route
  // See documentation for <Routes /> for more info
  const pages = import.meta.glob('./pages/**/!(*.test.[jt]sx)*.([jt]sx)', {
    eager: true,
  });

  return (
    <PolarisProvider>
      <BrowserRouter>
        <AppBridgeProvider>
          <QueryProvider>
            <ToastProvider>
              <NavigationMenu
                navigationLinks={[
                  {
                    label: 'Analytics',
                    destination: '/analytics',
                  },
                  {
                    label: 'Campaigns',
                    destination: '/campaigns',
                  },
                  {
                    label: 'Translation',
                    destination: '/translation',
                  },
                  {
                    label: 'Pricing',
                    destination: '/pricing',
                  },
                  // {
                  //   label: 'Sales Pop',
                  //   destination: '/campaigns/sales-pop',
                  // },
                  // {
                  //   label: 'Visitor Count',
                  //   destination: '/campaigns/visitor-count',
                  // },
                  // {
                  //   label: 'Sold Count',
                  //   destination: '/campaigns/sold-count',
                  // },
                ]}
              />
              <Routes pages={pages} />
            </ToastProvider>
          </QueryProvider>
        </AppBridgeProvider>
      </BrowserRouter>
    </PolarisProvider>
  );
}
