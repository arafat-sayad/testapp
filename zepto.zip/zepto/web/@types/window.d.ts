export {}
declare global {
  interface Window {
    __SHOPIFY_DEV_HOST: string
  }
}
