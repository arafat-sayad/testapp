// import {
//   dekstopItemData,
//   displayPageOpt,
//   formatOptions,
//   mobileItemData,
// } from './basicSettings';
// import { colorPickerData, templateColors } from './styleSettings';

// export {
//   colorPickerData,
//   dekstopItemData,
//   displayPageOpt,
//   formatOptions,
//   mobileItemData,
//   templateColors,
// };

export * from './basicSettings';
export * from './campaign';
export * from './dashboardConstants';
export * from './styleSettings';
