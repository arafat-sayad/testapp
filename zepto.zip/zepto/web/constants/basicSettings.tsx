export const displayPageOpt = [
  { label: 'All Page', value: 'all-page' },
  { label: 'Home Page Only', value: 'home-page' },
  { label: 'Exactly Following the URL', value: 'folling-url' },
  { label: 'Only Page with URL', value: 'only-page-url' },
  { label: 'Any Page Except the URL', value: 'any-page-url' },
];

export const dekstopItemData: {
  id: string;
  position: 'bottom-left' | 'top-left' | 'bottom-right' | 'top-right';
  text: string;
}[] = [
  {
    id: '1',
    position: 'top-left',
    text: 'Top Left',
  },
  {
    id: '2',
    position: 'top-right',
    text: 'Top Right',
  },
  {
    id: '3',
    position: 'bottom-left',
    text: 'Bottom Left',
  },
  {
    id: '4',
    position: 'bottom-right',
    text: 'Bottom Right',
  },
];

export const mobileItemData: {
  id: string;
  position: 'top' | 'bottom';
  text: string;
}[] = [
  {
    id: '1',
    position: 'bottom',
    text: 'Bottom',
  },
  {
    id: '2',
    position: 'top',
    text: 'Top',
  },
];

export const formatOptions = [
  { label: 'Seconds', value: 'seconds' },
  { label: 'Minutes', value: 'minutes' },
  { label: 'Hours', value: 'hours' },
];

export const salesFormatOptions = [
  { label: 'Minutes', value: 'minutes' },
  { label: 'Hours', value: 'hours' },
  { label: 'Days', value: 'days' },
];

export const productFilterOptions = [
  { label: 'All Products', value: 'all' },
  { label: 'Include Products', value: 'include' },
  { label: 'Exclude Products', value: 'exclude' },
];
