import { PopupType } from '@type/index';
import SalesPopup from '../assets/icons/SalesPopup';
import SoldCountIcon from '../assets/icons/SoldCountIcon';
import VisitorCountIcon from '../assets/icons/VisitorCountIcon';

export const campaignCardData = [
  {
    id: '1',
    image: <SalesPopup />,
    title: 'Sales Pop',
    description:
      'Highlight recent orders to foster trust and create a sense of FOMO (fear of missing out).',
    link: '/campaigns/sales-pop',
    popup_type: PopupType.SalePopup,
  },
  {
    id: '2',
    image: <VisitorCountIcon />,
    title: 'Visitor Count',
    description:
      'Highlight recent orders to foster trust and create a sense of FOMO (fear of missing out).',
    link: '/campaigns/visitor-count',
    popup_type: PopupType.VisitorCount,
  },
  {
    id: '3',
    image: <SoldCountIcon />,
    title: 'Sold Count',
    description:
      'Highlight recent orders to foster trust and create a sense of FOMO (fear of missing out).',
    link: '/campaigns/sold-count',
    popup_type: PopupType.SoldCount,
  },
];
