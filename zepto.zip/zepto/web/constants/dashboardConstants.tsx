import AutomationIcon from '../assets/icons/AutomationIcon';
import CreateAppIcon from '../assets/icons/CreateAppIcon';
import StoreManagedIcon from '../assets/icons/StoreManagedIcon';

import reviewXpo from '../assets/images/review-xpo.png';
import zeptoImg from '../assets/images/zepto-app.png';

export const onBoardCardData: {
  id: string;
  title: string;
  content: string;
  icon: React.ReactNode;
  buttonText: string;
  buttonType: 'primary' | 'neutral' | 'ghost';
}[] = [
  {
    id: '1',
    title: 'Create campaign',
    content:
      'Create a powerful strategy to promote marketing campaign boosting sales and decreasing cart abandonment.',
    icon: <CreateAppIcon />,
    buttonText: 'Manage Campaigns',
    buttonType: 'neutral',
  },
  {
    id: '2',
    title: 'Integrate with theme',
    content: `Enable the application within Shopify's Theme Editor to ensure its visibility on your store.`,
    icon: <AutomationIcon />,
    buttonText: 'Integrate App',
    buttonType: 'primary',
  },
  {
    id: '3',
    title: 'View in storefront',
    content: `View how your created campaigns appear in your store.`,
    icon: <StoreManagedIcon />,
    buttonText: 'View Store',
    buttonType: 'neutral',
  },
];

export const recomendedAppData = [
  {
    id: '1',
    image: zeptoImg,
    title: 'Zepto Product Personalizer',
    content:
      'Add Unlimited Custom Product Options with Live Preview. A Visual Personalizer to boost sales.',
    linkText: 'Free to install. Additional charges may apply.',
    link: 'https://apps.shopify.com/product-personalizer',
  },
  {
    id: '2',
    image: reviewXpo,
    title: 'ReviewXpo Product Reviews App',
    content:
      'Collect, Import, and showcase customer reviews and ratings with automated email to grow your sales.',
    linkText: 'Free to install. Additional charges may apply.',
    link: 'https://apps.shopify.com/products-review-app',
  },
  // {
  //   id: '3',
  //   image: popupImg,
  //   title: 'Zepto PopUp Manager',
  //   content:
  //     'Enhance your sales potential with a Visual Personalizer offering limitless custom product options and live previews.',
  //   linkText: 'Free to install. Additional charges may apply.',
  // },
  // {
  //   id: '4',
  //   image: zeptoImg,
  //   title: 'Zepto Product Review App',
  //   content:
  //     'Add Unlimited Custom Product Options with Live Preview. A Visual Personalizer to boost sales.',
  //   linkText: 'Free to install. Additional charges may apply.',
  // },
];
