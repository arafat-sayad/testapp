import Template1 from '@assets/icons/templates/Template1';
import Template2 from '@assets/icons/templates/Template2';
import Template3 from '@assets/icons/templates/Template3';
import Template4 from '@assets/icons/templates/Template4';
import Template5 from '@assets/icons/templates/Template5';

export const colorPickerData: {
  id: string;
  name: 'background' | 'content' | 'time' | 'action';
  text: string;
}[] = [
  {
    id: '1',
    name: 'background',
    text: 'Background Color',
  },
  {
    id: '2',
    name: 'content',
    text: 'Content Color',
  },
  {
    id: '3',
    name: 'time',
    text: 'Time Color',
  },
  {
    id: '4',
    name: 'action',
    text: 'Action Color',
  },
];

export const templateColors = {
  '1': {
    background: '#ffffff',
    content: '#404040',
    time: '#404040',
    action: '#391363',
  },
  '2': {
    background: '#ffffff',
    content: '#404040',
    time: '#404040',
    action: '#E03E1A',
  },
  '3': {
    background: '#ffffff',
    content: '#404040',
    time: '#404040',
    action: '#F79722',
  },
  '4': {
    background: '#ffffff',
    content: '#404040',
    time: '#404040',
    action: '#8A38F5',
  },
  '5': {
    background: '#ffffff',
    content: '#404040',
    time: '#404040',
    action: '#0C8CE9',
  },
};

export const templates: {
  key: '1' | '2' | '3' | '4' | '5';
  Template: ({
    active,
    onClick,
  }: {
    active?: boolean | undefined;
    onClick?: (() => void) | undefined;
  }) => JSX.Element;
}[] = [
  {
    key: '1',
    Template: Template1,
  },
  {
    key: '2',
    Template: Template2,
  },
  {
    key: '3',
    Template: Template3,
  },
  {
    key: '4',
    Template: Template4,
  },
  {
    key: '5',
    Template: Template5,
  },
];
