import { ToggleCampaignReq } from '@type/index';

export const fetchCampaigns = async () => {
  try {
    const url = import.meta.env.VITE_API_URL;

    const res = await fetch(`${url}/api/popups`);

    if (!res.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await res.json();
    return data.data;
  } catch (error) {
    console.error('Error fetching campaign:', error);
    throw error;
  }
};

export const toggleCampaignStatus = async ({
  popupType,
  body,
}: ToggleCampaignReq) => {
  try {
    const url = import.meta.env.VITE_API_URL;
    const res = await fetch(`${url}/api/popups/${popupType}/status-toggle`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      // You can optionally include a request body if needed
      body: JSON.stringify({ status: body.status }),
    });

    if (!res.ok) {
      throw new Error('Network response was not ok');
    }

    // Return the response if needed
    const resData = await res.json();
    return resData;
  } catch (error) {
    console.error('Error toggling campaign status:', error);
    throw error;
  }
};
