export const fetchAnalytics = async () => {
  try {
    const url = import.meta.env.VITE_API_URL;
    const res = await fetch(`${url}/api/analytics`);

    if (!res.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await res.json();
    return data.data;
  } catch (error) {
    console.error('Error fetching campaign:', error);
    throw error;
  }
};
