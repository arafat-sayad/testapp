export * from './apiDataType';

import { templateColors } from '@constants/index';

export interface PreviewCardProps {
  forMobile?: boolean;
  colors: {
    background: string;
    content: string;
    time: string;
    action: string;
  };
  template: '1' | '2' | '3' | '4' | '5';
}

export interface PositionProps {
  position: 'bottom-left' | 'top-left' | 'bottom-right' | 'top-right';
}

export interface MobilePosition {
  position: 'bottom' | 'top';
}

export interface CampaignCustomizeInterface {
  view: 'desktop' | 'mobile';
  toggleView: (view: 'desktop' | 'mobile') => void;
  content: string;
  handleContentChange: (value: string) => void;
  desktopPosition: 'bottom-left' | 'top-left' | 'bottom-right' | 'top-right';
  mobilePosition: 'top' | 'bottom';
  toggleDesktopPosition: (position: PositionProps['position']) => void;
  toggleMobilePosition: (position: MobilePosition['position']) => void;
  activeMobile: boolean;
  toggleActiveMobile: () => void;
  displaySettings: {
    beforeTime: string;
    afterTime: string;
    dispayPage: string;
    link: string;
  };
  handleDisplayChange: (newValue: string | string[], key: string) => void;
  colors: {
    background: string;
    content: string;
    time: string;
    action: string;
  };
  activeTemplate: keyof typeof templateColors;
  handleHexChange: (
    key: 'background' | 'content' | 'time' | 'action',
    value: string
  ) => void;
  handleActiveChange: (value: keyof typeof templateColors) => void;
}

export interface DefaultSettingsProps {
  content: CampaignCustomizeInterface['content'];
  displaySettings: CampaignCustomizeInterface['displaySettings'];
  activeMobile: CampaignCustomizeInterface['activeMobile'];
  mobilePosition: CampaignCustomizeInterface['mobilePosition'];
  desktopPosition: CampaignCustomizeInterface['desktopPosition'];
  activeTemplate: CampaignCustomizeInterface['activeTemplate'];
  colors: CampaignCustomizeInterface['colors'];
}

export enum PopupType {
  SoldCount = 'sold_count',
  SalePopup = 'sale_popup',
  VisitorCount = 'visitor_count',
}

export interface CampaignsResponseTypes {
  popup_type: PopupType;
  shop_id: number | string;
  status: 0 | 1;
}

export interface CampaignsDataTypes extends CampaignsResponseTypes {
  id: string;
  image: JSX.Element;
  title: string;
  description: string;
  link: string;
}
