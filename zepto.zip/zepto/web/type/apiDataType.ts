import { PopupType } from '.';

export interface ToggleCampaignReq {
  popupType: PopupType;
  body: { status: 0 | 1 };
}
