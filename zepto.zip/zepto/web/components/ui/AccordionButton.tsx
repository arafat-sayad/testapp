import { Icon } from '@shopify/polaris';
import { ChevronDownIcon } from '@shopify/polaris-icons';
import clsx from 'clsx';

interface AccordionButtonProps {
  open: boolean;
  onClick: () => void;
  children: JSX.Element | string;
}

const AccordionButton = ({ open, onClick, children }: AccordionButtonProps) => {
  return (
    <button
      className="flex items-center justify-between py-[10px] px-2 border-b border-natural-25 bg-inherit cursor-pointer transition-all duration-200 hover:bg-natural-25 rounded-md"
      onClick={onClick}
    >
      <h4 className="text-sm text-natural-800">{children}</h4>
      <span
        className={clsx('transition-all duration-300', open && 'rotate-180')}
      >
        <Icon source={ChevronDownIcon} />
      </span>
    </button>
  );
};

export default AccordionButton;
