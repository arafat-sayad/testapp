import { Icon } from '@shopify/polaris';
import { clsx } from 'clsx';
import React, { useState } from 'react';

interface ButtonProps {
  type?: 'primary' | 'neutral' | 'ghost';
  size?: 'large' | 'medium' | 'small';
  icon?:
    | React.FunctionComponent<React.SVGProps<SVGSVGElement>>
    | 'placeholder'
    | string;
  suffixIcon?: React.ReactNode;
  isLoading?: boolean;
  disabled?: boolean;
  children?: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

const CustomButton = ({
  type = 'neutral',
  size = 'large',
  icon,
  className,
  onClick,
  suffixIcon,
  children,
  disabled,
}: ButtonProps) => {
  const [onPress, setOnPress] = useState<boolean>(false);
  const common =
    'text-sm rounded-md font-medium transition-all duration-200 flex items-center justify-center gap-[6px] cursor-pointer text-center';

  const sizeStyle = {
    large: 'py-2 px-4',
    medium: 'py-2 px-4',
    small: 'py-1 px-2',
  };

  const typeStyle = {
    primary: 'text-white bg-primary hover:bg-primary-600',
    neutral: `text-natural-900 bg-natural-50 hover:bg-natural-100 ${disabled && 'bg-natural-25 !text-natural-200 hover:bg-natural-50 !cursor-auto'}`,
    ghost: 'bg-transparent hover:bg-primary-25',
  };

  const onPressStye = {
    primary: '',
    neutral:
      '0px 2px 1px 0px rgba(20, 20, 20, 0.16) inset, 1px 0px 1px 0px rgba(20, 20, 20, 0.08) inset, -1px 0px 1px 0px rgba(20, 20, 20, 0.08) inset',
    ghost:
      '0px 2px 1px 0px rgba(20, 20, 20, 0.16) inset, 1px 0px 1px 0px rgba(20, 20, 20, 0.08) inset, -1px 0px 1px 0px rgba(20, 20, 20, 0.08) inset',
  };

  return (
    <button
      className={clsx(common, sizeStyle[size], typeStyle[type], className)}
      style={{
        boxShadow: onPress ? onPressStye[type] : '',
      }}
      onMouseDown={() => setOnPress(true)}
      onMouseUp={() => setOnPress(false)}
      onClick={onClick}
      disabled={disabled}
    >
      {/* {icon && (
        <span
          className={clsx(
            'h-full flex flex-col items-center justify-center',
            onPress ? 'translate-y-[1px]' : ''
          )}
        >
          {icon}
        </span>
      )} */}

      {icon && (
        <button className={clsx(type === 'primary' && 'text-white')}>
          <Icon source={icon} />
        </button>
      )}

      {children && (
        <span className={onPress ? 'translate-y-[1px]' : ''}>{children}</span>
      )}
      {suffixIcon && (
        <span
          className={clsx(
            'h-full  flex flex-col items-center justify-center',
            onPress ? 'translate-y-[1px]' : ''
          )}
        >
          {suffixIcon}
        </span>
      )}
    </button>
  );
};

export default CustomButton;
