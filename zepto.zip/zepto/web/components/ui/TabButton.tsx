import { Icon } from '@shopify/polaris';
import clsx from 'clsx';
import React, { useState } from 'react';

interface TabButtonProps {
  active: boolean;
  icon?: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
  onClick: () => void;
  children?: JSX.Element | string;
}

const TabButton = ({ active, icon, children, onClick }: TabButtonProps) => {
  const [onPerss, setOnPress] = useState<boolean>(false);

  return (
    <div
      className={clsx(
        'border-b border-natural-100 w-1/2 relative ',
        active &&
          `after:content-[""] after:absolute after:left-0 after:bottom-0 after:w-full after:h-[2px] after:bg-primary after:rounded-full`
      )}
    >
      <button
        className={clsx(
          'px-4 py-[10px] flex items-center justify-center gap-1 rounded-md text-natural-500 text-sm font-medium cursor-pointer bg-inherit hover:bg-natural-25 shadow-none w-full',
          onPerss && '!bg-natural-50',
          active && `text-primary hover:bg-primary-25 border-primary`,
          active && onPerss && '!bg-primary-50'
        )}
        onClick={onClick}
        onMouseDown={() => setOnPress(true)}
        onMouseUp={() => setOnPress(false)}
      >
        {icon ? (
          <span className={active ? '[&>span>svg]:text-primary' : ''}>
            <Icon source={icon} tone={active ? 'primary' : 'subdued'} />
          </span>
        ) : null}
        <span>{children}</span>
      </button>
    </div>
  );
};

export default TabButton;
