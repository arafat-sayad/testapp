import { Text } from '@shopify/polaris';

const PageTitle = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="py-4 px-9 fixed top-0 left-0 w-full bg-natural-25 border-b-[1px] border-natural-100 z-50">
      <Text as="h1" variant="headingXl" fontWeight="regular">
        {children}
      </Text>
    </div>
  );
};

export default PageTitle;
