import CustomPanel from '../feature/customize/CustomPanel';
import PreviewSection from '../feature/customize/PreviewSection';

import { formatOptions } from '@constants/basicSettings';
import { displayPageOpt, templateColors } from '@constants/index';
import useCampaignCustomize from '@hooks/useCampaignCustomize';
import {
  BlockStack,
  Box,
  ChoiceList,
  Select,
  TextField,
} from '@shopify/polaris';
import { DefaultSettingsProps } from '@type/index';
import formatString from '@utils/formatString';
import { useCallback, useState } from 'react';
import ContentInput from '../feature/customize/basic-settings/ContentInput';
import DisplaySettings from '../feature/customize/basic-settings/DisplaySettings';
import PositionSettings from '../feature/customize/basic-settings/PositionSettings';
import StylesContent from '../feature/customize/style-stettings/StylesContent';
import SoldCountCard from '../feature/sold-count/SoldCountCard';
import CampCustLayout from '../layout/CampCustLayout';

const SoldCount = () => {
  const defaultSettings: DefaultSettingsProps = {
    content: '[OrderCount] have been placed for this beautiful product',
    displaySettings: {
      beforeTime: '10',
      afterTime: '10',
      dispayPage: displayPageOpt[3].value,
      link: '',
    },
    activeMobile: false,
    desktopPosition: 'bottom-left',
    mobilePosition: 'bottom',
    activeTemplate: '1',
    colors: templateColors['1'],
  };

  const {
    view,
    content,
    handleContentChange,
    toggleView,
    desktopPosition,
    mobilePosition,
    colors,
    activeTemplate,
    handleHexChange,
    handleActiveChange,
    displaySettings,
    handleDisplayChange,
    toggleActiveMobile,
    toggleMobilePosition,
    toggleDesktopPosition,
    activeMobile,
  } = useCampaignCustomize({ defaultSettings });

  const [settingsValue, setSettingsValue] = useState({
    type: ['random-number'],
    minRange: '10',
    maxRange: '50',
    hideMin: '10',
    lookbackTime: '24',
    format: 'minutes',
    productFilter: 'all',
    callToAction: `Why don't you?`,
  });

  const handleChange = useCallback(
    (newValue: string | string[], key: string) => {
      setSettingsValue((prev) => ({ ...prev, [key]: newValue }));
    },
    []
  );

  const dynamicVariables = [
    { id: '1', text: '+ OrderCount', value: '[OrderCount]' },
  ];

  const values = {
    OrderCount: '10 Orders',
  };

  const contents = {
    content: formatString(content, values),
    format: settingsValue.format,
    lookbackTime: settingsValue.lookbackTime,
    callToAction: settingsValue.callToAction,
  };

  return (
    <CampCustLayout pageTitle="Campaigns / Sold Count">
      <CustomPanel
        stylesContent={
          <StylesContent
            colors={colors}
            activeTemplate={activeTemplate}
            handleHexChange={handleHexChange}
            handleActiveChange={handleActiveChange}
          />
        }
      >
        <Box paddingBlockStart="600">
          <BlockStack gap="400">
            <ContentInput
              content={content}
              handleContentChange={handleContentChange}
              dynamicVariables={dynamicVariables}
            />

            <ChoiceList
              title=""
              choices={[
                { label: 'Real Number', value: 'real-number' },
                { label: 'Random Number', value: 'random-number' },
              ]}
              selected={settingsValue.type}
              onChange={(value: string[]) => {
                handleChange(value, 'type');
              }}
            />

            {settingsValue.type.includes('random-number') && (
              <div className="flex items-end gap-2">
                <TextField
                  label="Number Range"
                  type="number"
                  placeholder="Min"
                  value={settingsValue.minRange}
                  onChange={(value) => {
                    handleChange(value, 'minRange');
                  }}
                  autoComplete="off"
                />

                <TextField
                  label=""
                  type="number"
                  value={settingsValue.maxRange}
                  onChange={(value) => {
                    handleChange(value, 'maxRange');
                  }}
                  placeholder="Max"
                  autoComplete="off"
                />
              </div>
            )}

            {settingsValue.type.includes('real-number') && (
              <TextField
                label="Hide If Minimum Number"
                type="number"
                placeholder="10"
                value={settingsValue.hideMin}
                onChange={(value) => {
                  handleChange(value, 'hideMin');
                }}
                autoComplete="off"
              />
            )}

            <div className="flex items-end gap-2">
              <div className="w-[60%]">
                <TextField
                  label="Lookback Time"
                  type="number"
                  placeholder="24"
                  value={settingsValue.lookbackTime}
                  onChange={(value) => {
                    handleChange(value, 'lookbackTime');
                  }}
                  autoComplete="off"
                />
              </div>

              <div className="w-[40%]">
                <Select
                  label="Format"
                  options={formatOptions}
                  value={settingsValue.format}
                  onChange={(value) => {
                    handleChange(value, 'format');
                  }}
                />
              </div>
            </div>

            <TextField
              label="Call to Action"
              value={settingsValue.callToAction}
              onChange={(value) => {
                handleChange(value, 'callToAction');
              }}
              placeholder={`Why don't you?`}
              autoComplete="off"
            />

            {/* Display Settings */}
            <DisplaySettings
              settingsValue={displaySettings}
              handleChange={handleDisplayChange}
            />

            {/* Position */}
            <PositionSettings
              mobilePosition={mobilePosition}
              desktopPosition={desktopPosition}
              toggleActiveMobile={toggleActiveMobile}
              toggleDesktopPosition={toggleDesktopPosition}
              activeMobile={activeMobile}
              toggleMobilePosition={toggleMobilePosition}
            />
          </BlockStack>
        </Box>
      </CustomPanel>

      <PreviewSection
        activeTemplate={activeTemplate}
        view={view}
        toggleView={toggleView}
        mobilePosition={mobilePosition}
        desktopPosition={desktopPosition}
        previewCard={
          <SoldCountCard
            template={activeTemplate}
            colors={colors}
            forMobile={view === 'mobile'}
            contents={contents}
          />
        }
      />
    </CampCustLayout>
  );
};

export default SoldCount;
