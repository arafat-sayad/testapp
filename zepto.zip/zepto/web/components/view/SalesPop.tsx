import CustomPanel from '../feature/customize/CustomPanel';
import PreviewSection from '../feature/customize/PreviewSection';

import {
  productFilterOptions,
  salesFormatOptions,
} from '@constants/basicSettings';
import { displayPageOpt, templateColors } from '@constants/index';
import useCampaignCustomize from '@hooks/useCampaignCustomize';
import {
  BlockStack,
  Box,
  ChoiceList,
  Select,
  Text,
  TextField,
} from '@shopify/polaris';
import { DefaultSettingsProps } from '@type/index';
import formatString from '@utils/formatString';
import { useCallback, useState } from 'react';
import ContentInput from '../feature/customize/basic-settings/ContentInput';
import DisplaySettings from '../feature/customize/basic-settings/DisplaySettings';
import PositionSettings from '../feature/customize/basic-settings/PositionSettings';
import StylesContent from '../feature/customize/style-stettings/StylesContent';
import SalesPopCard from '../feature/sales-pop/SalesPopCard';
import CampCustLayout from '../layout/CampCustLayout';

const SalesPop = () => {
  const defaultSettings: DefaultSettingsProps = {
    content: '[CustomerName] from [Location] just bought [ProductTitle]',
    displaySettings: {
      beforeTime: '10',
      afterTime: '10',
      dispayPage: displayPageOpt[3].value,
      link: '',
    },
    activeMobile: false,
    desktopPosition: 'bottom-left',
    mobilePosition: 'bottom',
    activeTemplate: '1',
    colors: templateColors['1'],
  };

  const {
    view,
    content,
    handleContentChange,
    toggleView,
    desktopPosition,
    mobilePosition,
    colors,
    activeTemplate,
    handleHexChange,
    handleActiveChange,
    displaySettings,
    handleDisplayChange,
    toggleActiveMobile,
    toggleMobilePosition,
    toggleDesktopPosition,
    activeMobile,
  } = useCampaignCustomize({ defaultSettings });

  const [settingsValue, setSettingsValue] = useState({
    type: ['actual-order'],
    customerName: 'John Doe',
    location: 'New York, USA',
    manualCustomerName: `Federico, Peter, Christina`,
    manualLocation: `Turin, ITA Manchester, UK`,
    hideMin: '10',
    lookbackTime: '24',
    format: 'minutes',
    productFilter: 'all',
    callToAction: `Buy now`,
  });

  const [orderInfo, setOrderInfo] = useState({
    actualCustomers: ['Adam Smith\nJohn Doe'],
    actualLocations: ['New York, NY\nMiami, Florida'],
    manualCustomers: ['Adam Smith\nJohn Doe\nLeonardo DiCaprio'],
    manualLocations: ['New York, NY\nMiami, Florida'],
  });

  const actCusVal = orderInfo.actualCustomers.join('\t');
  const actLoca = orderInfo.actualLocations.join('\t');
  const manCusVal = orderInfo.manualCustomers.join('\t');
  const manLoca = orderInfo.manualLocations.join('\t');

  const handleInfoChange = useCallback((value: string, key: string) => {
    const newText = value;
    const newTextArray = newText.split('\t');

    setOrderInfo((prev) => ({ ...prev, [key]: newTextArray }));
  }, []);

  const handleChange = useCallback(
    (newValue: string | string[], key: string) => {
      setSettingsValue((prev) => ({ ...prev, [key]: newValue }));
    },
    []
  );

  const dynamicVariables = [
    { id: '1', text: '+ CustomerName', value: '[CustomerName]' },
    { id: '2', text: '+ Location', value: '[Location]' },
    { id: '3', text: '+ ProductTitle', value: '[ProductTitle]' },
  ];

  const values = {
    CustomerName: 'John Doe',
    Location: 'New York, USA',
    ProductTitle: 'Nike Shoe',
  };

  const contents = {
    content: formatString(content, values),
    format: settingsValue.format,
    lookbackTime: settingsValue.lookbackTime,
    callToAction: settingsValue.callToAction,
  };

  return (
    <CampCustLayout pageTitle="Campaigns / Sales Pop">
      <CustomPanel
        stylesContent={
          <StylesContent
            colors={colors}
            activeTemplate={activeTemplate}
            handleHexChange={handleHexChange}
            handleActiveChange={handleActiveChange}
          />
        }
      >
        <Box paddingBlockStart="600">
          <BlockStack gap="200">
            <ContentInput
              content={content}
              handleContentChange={handleContentChange}
              dynamicVariables={dynamicVariables}
            />

            <ChoiceList
              title=""
              choices={[
                { label: 'Actual Order', value: 'actual-order' },
                { label: 'Manual Order', value: 'manual-order' },
              ]}
              selected={settingsValue.type}
              onChange={(value: string[]) => {
                handleChange(value, 'type');
              }}
            />

            {settingsValue.type.includes('actual-order') && (
              <BlockStack as="div" gap={'400'}>
                <Box>
                  <TextField
                    label="Fallback Customer Name"
                    placeholder="Someone"
                    name="actualCustomers"
                    value={actCusVal}
                    onChange={(value) => {
                      handleInfoChange(value, 'actualCustomers');
                    }}
                    multiline={3}
                    autoComplete="off"
                    inputMode="text"
                  />
                  <div className=" text-natural-700">
                    <Text as="span" variant="bodyXs">
                      Separate with enter ↩ for multiple names
                    </Text>
                  </div>
                </Box>

                <Box>
                  <TextField
                    label="Fallback Location"
                    placeholder="Someone"
                    name="actualLocations"
                    value={actLoca}
                    onChange={(value) => {
                      handleInfoChange(value, 'actualLocations');
                    }}
                    multiline={3}
                    autoComplete="off"
                    inputMode="text"
                  />
                  <div className=" text-natural-700">
                    <Text as="span" variant="bodyXs">
                      Separate with enter ↩ for multiple names
                    </Text>
                  </div>
                </Box>
              </BlockStack>
            )}

            {settingsValue.type.includes('manual-order') && (
              <BlockStack as="div" gap={'400'}>
                <Box>
                  <TextField
                    label="Customer Name List"
                    placeholder="Federico"
                    name="manualCustomers"
                    value={manCusVal}
                    onChange={(value) => {
                      handleInfoChange(value, 'manualCustomers');
                    }}
                    multiline={3}
                    autoComplete="off"
                    inputMode="text"
                  />
                  <Text as="span" variant="bodyXs">
                    Separate with enter ↩ for multiple names
                  </Text>
                </Box>

                <Box>
                  <TextField
                    label="Location List"
                    placeholder="Turin, ITA, Manchester, UK"
                    name="manualLocations"
                    value={manLoca}
                    onChange={(value) => {
                      handleInfoChange(value, 'manualLocations');
                    }}
                    multiline={3}
                    autoComplete="off"
                    inputMode="text"
                  />
                  <div className=" text-natural-700">
                    <Text as="span" variant="bodyXs">
                      Separate with enter ↩ for multiple names
                    </Text>
                  </div>
                </Box>
              </BlockStack>
            )}

            <div className="flex items-end gap-2">
              <div className="w-[60%]">
                <TextField
                  label="Lookback Time"
                  type="number"
                  placeholder="24"
                  value={settingsValue.lookbackTime}
                  onChange={(value) => {
                    handleChange(value, 'lookbackTime');
                  }}
                  autoComplete="off"
                />
              </div>

              <div className="w-[40%]">
                <Select
                  label="Format"
                  options={salesFormatOptions}
                  value={settingsValue.format}
                  onChange={(value) => {
                    handleChange(value, 'format');
                  }}
                />
              </div>
            </div>

            <Select
              label="Product Filter"
              options={productFilterOptions}
              value={settingsValue.productFilter}
              onChange={(value) => {
                handleChange(value, 'productFilter');
              }}
            />

            <TextField
              label="Call to Action"
              value={settingsValue.callToAction}
              onChange={(value) => {
                handleChange(value, 'callToAction');
              }}
              placeholder={`Buy now`}
              autoComplete="off"
            />

            {/* Display Settings */}
            <DisplaySettings
              settingsValue={displaySettings}
              handleChange={handleDisplayChange}
            />

            {/* Position */}
            <PositionSettings
              mobilePosition={mobilePosition}
              desktopPosition={desktopPosition}
              toggleActiveMobile={toggleActiveMobile}
              toggleDesktopPosition={toggleDesktopPosition}
              activeMobile={activeMobile}
              toggleMobilePosition={toggleMobilePosition}
            />
          </BlockStack>
        </Box>
      </CustomPanel>

      <PreviewSection
        activeTemplate={activeTemplate}
        view={view}
        toggleView={toggleView}
        mobilePosition={mobilePosition}
        desktopPosition={desktopPosition}
        previewCard={
          <SalesPopCard
            template={activeTemplate}
            colors={colors}
            forMobile={view === 'mobile'}
            contents={contents}
          />
        }
      />
    </CampCustLayout>
  );
};

export default SalesPop;
