import PlanCard from '@components/feature/pricing/PlanCard';
import { TitleBar } from '@shopify/app-bridge-react';
import { Box, Grid, Icon, Page, Text } from '@shopify/polaris';
import { ConfettiIcon } from '@shopify/polaris-icons';
import clsx from 'clsx';
import { useState } from 'react';

interface TabButtonTypes {
  children: JSX.Element | string;
  className?: string;
  onClick: () => void;
}

const planData: {
  name: string;
  description: string;
  price: string;
  timeDuration: string;
  buttonText: string;
  buttonType: 'primary' | 'neutral' | 'ghost';
  recomended?: boolean;
  features: string[];
  disabled?: boolean;
}[] = [
  {
    name: 'Free',
    description: 'Get started with Shopify',
    price: '0',
    timeDuration: 'month',
    buttonText: 'Current Plan',
    buttonType: 'neutral',
    disabled: true,

    features: [
      'Unlimited products',
      'Unlimited orders',
      'Unlimited customers',
      'Unlimited products',
      'Unlimited orders',
      'Unlimited customers',
    ],
  },
  {
    name: 'Standard',
    description: 'Get started with Shopify',
    price: '39',
    timeDuration: 'month',
    buttonText: 'Choose Standard',
    buttonType: 'primary',
    recomended: true,
    features: [
      'Unlimited products',
      'Unlimited orders',
      'Unlimited customers',
      'Unlimited products',
      'Unlimited orders',
      'Unlimited customers',
    ],
  },
  {
    name: 'Advanced',
    description: 'Get started with Shopify',
    price: '59',
    timeDuration: 'month',
    buttonText: 'Choose Advanced',
    buttonType: 'neutral',

    features: [
      'Unlimited products',
      'Unlimited orders',
      'Unlimited customers',
      'Unlimited products',
      'Unlimited orders',
      'Unlimited customers',
    ],
  },
];

const TabButton = ({ children, className, onClick }: TabButtonTypes) => {
  return (
    <button
      className={clsx(
        'px-5 py-[6px] text-sm text-natural-800 rounded-md font-medium',
        className
      )}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

enum PricingEnum {
  monthly,
  annually,
}

const Pricing = () => {
  const [active, setActive] = useState<PricingEnum>(PricingEnum.monthly);

  const handleSwitch = (tab: PricingEnum) => {
    setActive(tab);
  };

  return (
    <Page>
      <TitleBar
        title="Pricing"
        // primaryAction={{
        //   content: 'Save Changes',
        //   onAction: () => console.log('save'),
        // }}
        // secondaryActions={[
        //   {
        //     content: 'Discard',
        //     onAction: () => console.log('cancel'),
        //   },
        // ]}
      />

      <div className="text-center text-natural-900 mt-5">
        {/* Title */}
        <Box>
          <Text as="h1" variant="heading2xl" fontWeight="semibold">
            Find the plan that works for you
          </Text>
          <Text as="p" variant="bodyLg" fontWeight="regular">
            All plans come with a 60-days money-back guarantee
          </Text>
        </Box>

        {/* Tab Button */}
        <div className="my-14">
          <div className="max-w-[200px] mx-auto bg-white border border-natural-100 rounded-md p-[2px] shadow-sm flex items-center relative">
            <TabButton
              className={
                active === PricingEnum.monthly ? '!bg-primary !text-white' : ''
              }
              onClick={() => handleSwitch(PricingEnum.monthly)}
            >
              Monthly
            </TabButton>
            <TabButton
              onClick={() => handleSwitch(PricingEnum.annually)}
              className={
                active === PricingEnum.annually ? '!bg-primary !text-white' : ''
              }
            >
              Annually
            </TabButton>

            <div
              className="absolute -right-9 -top-5 px-2 py-1 bg-[#93BF3C] text-primary text-xs flex items-center gap-[2px] rounded-full"
              onClick={() => handleSwitch(PricingEnum.annually)}
            >
              <Icon source={ConfettiIcon} />
              <span>Save 40%</span>
            </div>
          </div>
        </div>

        {/* Plans */}
        <Grid>
          {planData.map((item) => (
            <Grid.Cell key={item.name} columnSpan={{ sm: 6, md: 4, lg: 4 }}>
              <PlanCard {...item} />
            </Grid.Cell>
          ))}
        </Grid>
      </div>
    </Page>
  );
};

export default Pricing;
