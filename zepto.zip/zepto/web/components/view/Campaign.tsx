import { BlockStack, Grid, Layout } from '@shopify/polaris';

import { useMutation, useQuery, useQueryClient } from 'react-query';

import {
  CampaignsDataTypes,
  CampaignsResponseTypes,
  ToggleCampaignReq,
} from '@type/index';
import { useEffect, useState } from 'react';
import { campaignCardData } from '../../constants/campaign';
import { useToast } from '../../context/ToastContext';
import {
  fetchCampaigns,
  toggleCampaignStatus,
} from '../../services/campaignService';
import CampaignCard from '../feature/CampaignCard';

const Campaign = () => {
  // fetch campaign data
  const { data, isLoading, isError } = useQuery('campaigns', fetchCampaigns);
  const { showToast } = useToast();

  const queryClient = useQueryClient();

  // campaign status toggle api
  const toggleStatusMutation = useMutation(toggleCampaignStatus, {
    onSuccess: async (data) => {
      // Invalidate and refetch the campaigns query
      await queryClient.invalidateQueries('campaigns');
      await showToast(data?.message, data?.status === 'SUCCESS');
      console.log('data updated', data.message);
    },
  });

  const handleToggle = (data: ToggleCampaignReq) => {
    toggleStatusMutation.mutate(data);
  };

  // campaigndata merge with response data
  const [campaignsData, setCampaignsData] = useState<CampaignsDataTypes[]>([]);

  useEffect(() => {
    const newData = data?.popups?.map((pop: CampaignsResponseTypes) => {
      const staticData = campaignCardData.find(
        (item) => item.popup_type === pop.popup_type
      );

      return {
        ...staticData,
        ...pop,
      };
    });
    setCampaignsData(newData);
  }, [data]);

  return (
    <Layout>
      <Layout.Section>
        <BlockStack gap="400">
          <Grid>
            {data?.popups?.length &&
              campaignsData?.map((item) => (
                <Grid.Cell key={item.id} columnSpan={{ sm: 6, md: 6, lg: 4 }}>
                  <CampaignCard
                    image={item.image}
                    title={item.title}
                    description={item.description}
                    link={item.link}
                    status={Boolean(item.status)}
                    popup_type={item.popup_type}
                    handleToggle={handleToggle}
                  />
                </Grid.Cell>
              ))}
          </Grid>
        </BlockStack>
      </Layout.Section>
    </Layout>
  );
};

export default Campaign;
