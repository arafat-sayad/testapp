import {
  BlockStack,
  Box,
  Grid,
  InlineStack,
  Layout,
  Text,
} from '@shopify/polaris';

import HelpCard from '@components/feature/HelpCard';
import BannerInfo from '@components/ui/BannerInfo';
import { helpCardData } from '@utils/constants';
import {
  onBoardCardData,
  recomendedAppData,
} from '../../constants/dashboardConstants';
import CampaignTable from '../feature/CampaignTable';
import OnBoardCard from '../feature/OnBoardCard';
import RecomendedApp from '../feature/RecomendedApp';

const DashboardView = () => {
  return (
    <Layout>
      <BannerInfo />
      <Layout.Section>
        <Box as="div">
          <Text as="h1" variant="headingXl" fontWeight="medium">
            Ready to start using PopUp Manager? 👋
          </Text>
          <Text as="p" variant="bodyLg">
            It&apos;s only 3 steps, let`&apos;s get started...
          </Text>
        </Box>
      </Layout.Section>

      <Layout.Section>
        <BlockStack gap="300">
          {onBoardCardData.map((item) => (
            <OnBoardCard
              key={item.id}
              icon={item.icon}
              title={item.title}
              content={item.content}
              buttonText={item.buttonText}
              buttonType={item.buttonType}
            />
          ))}
        </BlockStack>
      </Layout.Section>

      <Layout.Section>
        <div className="bg-white rounded-xl p-5 mt-8 text-base">
          <Box paddingBlockEnd="500">
            <InlineStack as="div" align="space-between" blockAlign="center">
              <div className="text-base">
                <Text as="h3" fontWeight="medium">
                  Campaign List
                </Text>
              </div>
              <Box>
                <Text as="p" variant="bodyMd">
                  Analytics from last 7 days
                </Text>
              </Box>
            </InlineStack>
          </Box>
          <CampaignTable />
        </div>
      </Layout.Section>

      <Layout.Section>
        <div className="bg-white rounded-xl p-5 mt-8 text-base">
          <BlockStack>
            <div className="text-base pb-[1px]">
              <Text as="h3" fontWeight="medium">
                Recommended Apps
              </Text>
            </div>

            <div className="text-natural-700 leading-5">
              <Text as="p" variant="bodySm">
                Boost engagement and product promotion by expanding your app
                offerings to increase shopper sessions.
              </Text>
            </div>
          </BlockStack>

          <div className="mt-5">
            <Grid>
              {recomendedAppData.map((item) => (
                <Grid.Cell columnSpan={{ sm: 6, md: 6, lg: 6 }} key={item.id}>
                  <RecomendedApp
                    image={item.image}
                    title={item.title}
                    linkText={item.linkText}
                    content={item.content}
                    link={item.link}
                  />
                </Grid.Cell>
              ))}
            </Grid>
          </div>
        </div>
      </Layout.Section>

      <Layout.Section>
        <div className="bg-white rounded-xl p-5 my-8 text-base">
          <Box paddingBlockEnd={'400'}>
            <div className="text-base text-natural-900">
              <Text as="h2" fontWeight="medium">
                Help Center
              </Text>
            </div>
          </Box>
          <Grid gap={{ md: '200' }}>
            {helpCardData.map((item) => (
              <Grid.Cell columnSpan={{ sm: 6, md: 6, lg: 4 }} key={item.id}>
                <button className="lg:max-w-full max-w-[270px] hover:shadow-md rounded-xl text-left">
                  <HelpCard
                    title={item.title}
                    content={item.content}
                    icon={item.icon}
                  />
                </button>
              </Grid.Cell>
            ))}
          </Grid>
        </div>
      </Layout.Section>
    </Layout>
  );
};

export default DashboardView;
