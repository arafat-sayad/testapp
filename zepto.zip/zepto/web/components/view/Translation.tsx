import { Box, Card, Icon, InlineStack, Layout, Text } from '@shopify/polaris';
import { useState } from 'react';

import LanguageButton from '@components/feature/translation/LanguageButton';
import SalesPopTranslation from '@components/feature/translation/SalesPopTranslation';
import SoldCountTranslation from '@components/feature/translation/SoldCountTranslation';
import VisitorCountTranslation from '@components/feature/translation/VisitorCountTranslation';
import { InfoIcon } from '@shopify/polaris-icons';
import TabButton from '../ui/TabButton';

enum TabsEnum {
  Sales,
  Visitor,
  Sold,
}

const tabsData = [
  {
    label: 'Sales Pop',
    value: TabsEnum.Sales,
  },
  {
    label: 'Visitor Count',
    value: TabsEnum.Visitor,
  },
  {
    label: 'Sold Count',
    value: TabsEnum.Sold,
  },
];

const Translation = () => {
  const [activeTab, setActiveTab] = useState<TabsEnum>(TabsEnum.Sales);

  const handleTabChange = (value: TabsEnum) => () => {
    setActiveTab(value);
  };

  const [activeLang, setActiveLang] = useState('Arabic (العربية)');

  return (
    <Layout>
      <Card>
        <div className="w-[928px] min-h-[88vh]">
          <Box>
            <InlineStack as="div" align="space-between" blockAlign="center">
              <div className="w-1/2">
                <div className="flex items-center">
                  {tabsData.map((tab) => (
                    <TabButton
                      key={tab.value}
                      active={activeTab === tab.value}
                      onClick={handleTabChange(tab.value)}
                    >
                      {tab.label}
                    </TabButton>
                  ))}
                </div>
              </div>

              <div className="w-1/2">
                <InlineStack as="div" gap="300" blockAlign="center" align="end">
                  <Text as="p" variant="bodyLg">
                    Translate to
                  </Text>
                  <LanguageButton
                    activeLang={activeLang}
                    setActiveLang={setActiveLang}
                  />
                </InlineStack>
              </div>
            </InlineStack>
          </Box>

          {/* Message */}
          <div className="w-full bg-primary-50  text-primary p-3 my-6 border border-[#DFD9E6] rounded-md ">
            <div className="flex gap-2">
              <Box>
                <Icon source={InfoIcon} />
              </Box>
              <Box>
                <Text as="p" variant="bodyLg" fontWeight="regular">
                  You should write in Translation Fields in your chosen
                  language, which will be displayed on the PopUp when your
                  customers visit. The Variables must have to set in Content
                  Text that you used from the PopUp Customization settings.
                </Text>
              </Box>
            </div>
          </div>

          {activeTab === TabsEnum.Sales && (
            <SalesPopTranslation activeLang={activeLang} />
          )}

          {activeTab === TabsEnum.Visitor && (
            <VisitorCountTranslation activeLang={activeLang} />
          )}

          {activeTab === TabsEnum.Sold && (
            <SoldCountTranslation activeLang={activeLang} />
          )}
        </div>
      </Card>
    </Layout>
  );
};

export default Translation;
