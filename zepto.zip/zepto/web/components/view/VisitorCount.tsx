import CustomPanel from '../feature/customize/CustomPanel';
import PreviewSection from '../feature/customize/PreviewSection';

import { displayPageOpt, templateColors } from '@constants/index';
import useCampaignCustomize from '@hooks/useCampaignCustomize';
import {
  BlockStack,
  Box,
  ChoiceList,
  InlineStack,
  Text,
  TextField,
} from '@shopify/polaris';
import { DefaultSettingsProps } from '@type/index';
import formatString from '@utils/formatString';
import { useCallback, useState } from 'react';
import ToggleButton from '../feature/ToggleButton';
import ContentInput from '../feature/customize/basic-settings/ContentInput';
import DisplaySettings from '../feature/customize/basic-settings/DisplaySettings';
import PositionSettings from '../feature/customize/basic-settings/PositionSettings';
import StylesContent from '../feature/customize/style-stettings/StylesContent';
import VisitorCountCard from '../feature/visitor-count/VisitorCountCard';
import CampCustLayout from '../layout/CampCustLayout';

const VisitorCount = () => {
  const defaultSettings: DefaultSettingsProps = {
    content: '[LiveVisitor] are watching this store right now',
    displaySettings: {
      beforeTime: '10',
      afterTime: '10',
      dispayPage: displayPageOpt[3].value,
      link: '',
    },
    activeMobile: false,
    desktopPosition: 'bottom-left',
    mobilePosition: 'bottom',
    activeTemplate: '1',
    colors: templateColors['1'],
  };

  const {
    view,
    content,
    handleContentChange,
    toggleView,
    desktopPosition,
    mobilePosition,
    colors,
    activeTemplate,
    handleHexChange,
    handleActiveChange,
    displaySettings,
    handleDisplayChange,
    toggleActiveMobile,
    toggleMobilePosition,
    toggleDesktopPosition,
    activeMobile,
  } = useCampaignCustomize({ defaultSettings });

  const [settingsValue, setSettingsValue] = useState({
    type: ['manual-visitor'],
    minRange: '10',
    maxRange: '50',
    hideMin: '10',
    lookbackTime: '24',
    format: 'minutes',
    productFilter: 'all',
    callToAction: `Why don't you?`,
  });

  const [activeBranding, setActiveBranding] = useState(true);

  const toggleActiveBranding = () => {
    setActiveBranding((prev) => !prev);
  };

  const handleChange = useCallback(
    (newValue: string | string[], key: string) => {
      setSettingsValue((prev) => ({ ...prev, [key]: newValue }));
    },
    []
  );

  const dynamicVariables = [
    { id: '1', text: '+ LiveVisitor', value: '[LiveVisitor]' },
  ];

  const values = {
    LiveVisitor: '24 shoppers',
  };

  const contents = {
    content: formatString(content, values),
    showBranding: activeBranding,
  };

  return (
    <CampCustLayout pageTitle="Campaigns / Visitor Count">
      <CustomPanel
        stylesContent={
          <StylesContent
            colors={colors}
            activeTemplate={activeTemplate}
            handleHexChange={handleHexChange}
            handleActiveChange={handleActiveChange}
          />
        }
      >
        <Box paddingBlockStart="600">
          <BlockStack gap="400">
            <ContentInput
              content={content}
              handleContentChange={handleContentChange}
              dynamicVariables={dynamicVariables}
            />

            <ChoiceList
              title=""
              choices={[
                { label: 'Actual Visitor', value: 'real-visitor' },
                { label: 'Manual Visitor', value: 'manual-visitor' },
              ]}
              selected={settingsValue.type}
              onChange={(value: string[]) => {
                handleChange(value, 'type');
              }}
            />

            {settingsValue.type.includes('manual-visitor') && (
              <div className="flex items-end gap-2">
                <TextField
                  label="Number Range"
                  type="number"
                  placeholder="Min"
                  value={settingsValue.minRange}
                  onChange={(value) => {
                    handleChange(value, 'minRange');
                  }}
                  autoComplete="off"
                />

                <TextField
                  label=""
                  type="number"
                  value={settingsValue.maxRange}
                  onChange={(value) => {
                    handleChange(value, 'maxRange');
                  }}
                  placeholder="Max"
                  autoComplete="off"
                />
              </div>
            )}

            {settingsValue.type.includes('real-visitor') && (
              <TextField
                label="Hide If Minimum Visitor"
                type="number"
                placeholder="10"
                value={settingsValue.hideMin}
                onChange={(value) => {
                  handleChange(value, 'hideMin');
                }}
                autoComplete="off"
              />
            )}

            <InlineStack as="div" blockAlign="center" gap="150">
              <Text as="span" variant="bodyLg">
                PopUp Manager Branding
              </Text>
              <ToggleButton
                active={activeBranding}
                handleToggle={toggleActiveBranding}
              />
            </InlineStack>

            {/* Display Settings */}
            <DisplaySettings
              settingsValue={displaySettings}
              handleChange={handleDisplayChange}
            />

            {/* Position */}
            <PositionSettings
              mobilePosition={mobilePosition}
              desktopPosition={desktopPosition}
              toggleActiveMobile={toggleActiveMobile}
              toggleDesktopPosition={toggleDesktopPosition}
              activeMobile={activeMobile}
              toggleMobilePosition={toggleMobilePosition}
            />
          </BlockStack>
        </Box>
      </CustomPanel>

      <PreviewSection
        activeTemplate={activeTemplate}
        view={view}
        toggleView={toggleView}
        mobilePosition={mobilePosition}
        desktopPosition={desktopPosition}
        previewCard={
          <VisitorCountCard
            forMobile={view === 'mobile'}
            colors={colors}
            template={activeTemplate}
            contents={contents}
          />
        }
      />
    </CampCustLayout>
  );
};

export default VisitorCount;
