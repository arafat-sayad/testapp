import { Box, Card, Grid, InlineStack, Layout, Text } from '@shopify/polaris';
import { statsCardData } from '../../utils/constants';
import { StatsCard } from '../feature';

import DateRange from '@components/feature/DateRange';

import { useQuery } from 'react-query';

import { fetchAnalytics } from '@services/analyticsService';
import moment from 'moment';
import { useEffect, useState } from 'react';
import AnalyticsChart from '../feature/AnalyticsChart';

interface DateRange {
  from: Date;
  to: Date;
}

interface AnalyticsData {
  [date: string]: {
    [category: string]: number;
  };
}

const Analytics = () => {
  const { data, isLoading, isError, isFetched } = useQuery(
    'analytics',
    fetchAnalytics
  );

  const [dateRange, setDateRange] = useState<DateRange | {}>({});

  useEffect(() => {
    if (isFetched) {
      const from = Object.keys(data?.analytics)[0];
      const to = Object.keys(data?.analytics)[6];

      setDateRange({
        from,
        to,
      });
    }
  }, [data]);

  const labels =
    isFetched &&
    Object.keys(data?.analytics)?.map((item) => moment(item).format('MMM DD'));

  const formatAnalyticsData = (
    analyticsData: AnalyticsData
  ): {
    [category: string]: number[];
  } => {
    return Object.values(analyticsData).reduce<{
      [category: string]: number[];
    }>((acc, dateData) => {
      Object.entries(dateData).forEach(([category, value]) => {
        acc[category] = [...(acc[category] || []), value];
      });
      return acc;
    }, {});
  };
  const chartData = isFetched && formatAnalyticsData(data?.analytics);

  return (
    <Layout>
      <Layout.Section>
        <Grid>
          {Boolean(data) &&
            statsCardData.map((item) => (
              <Grid.Cell
                key={item.id}
                columnSpan={{ sm: 6, md: 6, lg: 4, xl: 4 }}
              >
                <StatsCard
                  title={item.title}
                  icon={item.icon}
                  name={item.name}
                  count={data?.count[item.id]}
                  toltipContent={item.toltipContent}
                />
              </Grid.Cell>
            ))}
        </Grid>
      </Layout.Section>

      <Layout.Section>
        {/* <div className="mt-10 bg-white px-5 pt-6 pb-8 w-full h-full rounded-xl"> */}
        <Card padding={'500'}>
          <InlineStack align="space-between" blockAlign="center">
            <Box as="div" paddingBlockStart={'200'}>
              <div className="font-medium text-base">
                <Text as="h4">Analytics Data</Text>
              </div>
            </Box>
            <Box as="div">
              <DateRange setDateRange={setDateRange} dateRange={dateRange} />
            </Box>
          </InlineStack>
          <div className="w-full pb-5 pt-2">
            {isFetched && (
              <AnalyticsChart labels={labels} chartData={chartData} />
            )}
          </div>
        </Card>
      </Layout.Section>
    </Layout>
  );
};

export default Analytics;
