import { BlockStack, Box, Card, InlineStack, Text } from '@shopify/polaris';

import { Link } from 'react-router-dom';
import CustomButton from '../ui/CustomButton';

interface OnBoardTypes {
  title: string;
  content: string;
  icon: React.ReactNode;
  buttonText: string;
  buttonType?: 'primary' | 'neutral' | 'ghost';
}

const OnBoardCard = ({
  title,
  content,
  icon,
  buttonText,
  buttonType,
}: OnBoardTypes) => {
  return (
    <Card>
      <div className="flex items-center justify-between ">
        <InlineStack blockAlign="center" gap="400" wrap={false}>
          <Box as="div">
            <div className="flex items-center justify-center w-20 h-20 rounded-full bg-primary-50 text-center">
              {icon}
            </div>
          </Box>
          <BlockStack gap="100">
            <div className="text-base">
              <Text as="h3" fontWeight="medium">
                {title}
              </Text>
            </div>
            <div className="text-natural-800">
              <Text as="p" variant="bodyLg">
                {content}
              </Text>
            </div>
          </BlockStack>
        </InlineStack>
        <div className="min-w-[200px] flex items-center justify-end">
          <Link to={'/campaigns'} className="no-underline">
            <CustomButton type={buttonType || 'neutral'}>
              {buttonText}
            </CustomButton>
          </Link>
        </div>
      </div>
    </Card>
  );
};

export default OnBoardCard;
