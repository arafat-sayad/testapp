import {
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LineElement,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Filler,
  Legend
);

interface AnalyticsChartProps {
  labels: string[];
  chartData: {
    [category: string]: number[];
  };
}

const AnalyticsChart = ({ labels, chartData }: AnalyticsChartProps) => {
  const options = {
    responsive: true,
    elements: {
      line: {
        tension: 0.3,
      },
    },
    plugins: {
      legend: {
        position: 'bottom' as const,
      },

      title: {
        display: true,
        text: '',
      },
    },
  };
  const data = {
    labels,
    datasets: [
      {
        fill: true,
        label: 'Engagements',
        data: chartData[1],
        borderSmooth: true,
        borderWidth: 1,
        borderColor: '#391363',
        backgroundColor: 'rgba(57, 19, 99, 0.12)',
      },
      {
        fill: true,
        label: 'Visitors',
        data: chartData[2],
        borderWidth: 1,
        borderColor: 'rgba(15, 97, 35, 1)',
        backgroundColor: 'rgba(15, 97, 35, 0.12)',
      },
      {
        fill: true,
        label: 'Impressions',
        data: chartData[3],
        borderWidth: 1,
        borderColor: 'rgba(178, 133, 18, 1)',
        backgroundColor: 'rgba(178, 133, 18, 0.12)',
      },
    ],
  };

  console.log('chartData', data);
  return (
    <Line options={options} data={data} className="w-full mx-auto p-0 m-0" />
  );
};

export default AnalyticsChart;
