import CustomButton from '@components/ui/CustomButton';
import {
  BlockStack,
  Box,
  Card,
  Divider,
  Icon,
  InlineStack,
  List,
  Text,
} from '@shopify/polaris';
import { CheckIcon } from '@shopify/polaris-icons';

interface PlanCardTypes {
  name: string;
  description: string;
  price: string;
  timeDuration: string;
  buttonText: string;
  buttonType?: 'primary' | 'neutral' | 'ghost';
  disabled?: boolean;
  recomended?: boolean;
  features: string[];
}

const PlanCard = ({
  name,
  description,
  price,
  timeDuration,
  buttonText,
  buttonType,
  features,
  disabled,
  recomended,
}: PlanCardTypes) => {
  return (
    <div
      className="text-start relative text-natural-800"
      style={
        recomended
          ? {
              border: '1px solid #391363',
              borderRadius: '12px',
            }
          : {}
      }
    >
      <Card padding={{ xs: '500' }}>
        <BlockStack as="div" gap="100">
          <div className="text-natural-900">
            <Text as="h2" variant="headingLg" fontWeight="semibold">
              {name}
            </Text>
          </div>
          <Text as="p" variant="bodyLg">
            {description}
          </Text>
        </BlockStack>

        <Box paddingBlock={'400'}>
          <Text as="p" variant="bodySm" alignment="start">
            Starting at
          </Text>

          <InlineStack as="div" blockAlign="center" gap={'200'}>
            <div className="text-natural-900 text-[32px] leading-[38px]">
              <Text as="h2" fontWeight="semibold">
                ${price}
              </Text>
            </div>
            <span className="text-base mt-1">/ {timeDuration}</span>
          </InlineStack>
        </Box>

        <div className="w-full mb-2 mt-1">
          <CustomButton
            className="w-full"
            disabled={disabled}
            type={buttonType}
          >
            {buttonText}
          </CustomButton>
        </div>

        <Box paddingBlock={'300'}>
          <Divider />
        </Box>

        <Box>
          <BlockStack as="ul" gap={'200'}>
            {features.map((feature) => (
              <List.Item key={feature}>
                <InlineStack as="div" blockAlign="center" gap={'200'}>
                  <div className="text-[#0f6123] py-[2px]">
                    <Icon source={CheckIcon} />
                  </div>
                  <div className="text-natural-800">
                    <Text as="p" variant="bodyLg">
                      {feature}
                    </Text>
                  </div>
                </InlineStack>
              </List.Item>
            ))}
          </BlockStack>
        </Box>
      </Card>

      {recomended && (
        <div className="absolute left-[calc(50%-60px)] -top-3">
          <button className="bg-primary text-white text-xs rounded-full px-3 py-1">
            Recommended
          </button>
        </div>
      )}
    </div>
  );
};

export default PlanCard;
