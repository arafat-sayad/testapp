import { SettingsIcon } from '@shopify/polaris-icons';
import { clsx } from 'clsx';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import CustomButton from '../ui/CustomButton';
import ToggleButton from './ToggleButton';

const tableData = {
  head: [
    'Campaign Type',
    'Last Started',
    'Visitors',
    'Impressions',
    'Engagements',
    'Status',
    'Customize',
  ],
  body: [
    {
      id: '1',
      campaignType: 'Sales Pop',
      lastStarted: '14 days ago',
      visitors: 56,
      impressions: 127,
      engagements: 28,
      status: true,
      customizeUrl: 'campaigns/sales-pop',
    },
    {
      id: '2',
      campaignType: 'Visitor Count',
      lastStarted: '27 days ago',
      visitors: 40,
      impressions: 96,
      engagements: 0,
      status: true,
      customizeUrl: 'campaigns/visitor-count',
    },
    {
      id: '3',
      campaignType: 'Sold Count',
      lastStarted: '-- days ago',
      visitors: 115,
      impressions: 289,
      engagements: 20,
      status: true,
      customizeUrl: 'campaigns/visitor-count',
    },
  ],
};

const CampaignTable = () => {
  const [campaignsStatus, setCampaignsStatus] = useState([
    {
      id: '1',
      status: true,
    },
    {
      id: '2',
      status: true,
    },
    {
      id: '3',
      status: false,
    },
  ]);

  const handleToggleStatus = (id: string) => {
    setCampaignsStatus(
      campaignsStatus.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            status: !item.status,
          };
        }
        return item;
      })
    );
  };

  return (
    <div className="relative overflow-x-auto">
      <table className="w-full text-sm text-left rtl:text-right border-collapse">
        <thead className="text-xs   text-natural-800   m-0 p-0">
          <tr>
            {tableData?.head.map((item, index) => (
              <th
                key={item}
                scope="col"
                className={clsx(
                  'px-6 py-3 font-medium bg-primary-25 ',
                  index === 0 && 'rounded-l-md',
                  index === tableData.head.length - 1 && 'rounded-r-md'
                )}
              >
                {item}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="">
          {tableData.body.map((item, index) => (
            <tr
              key={item.id}
              className={clsx(
                'bg-white border-b hover:bg-gray-50',
                tableData.body.length - 1 === index && 'border-none'
              )}
            >
              <td
                scope="row"
                className="px-6 py-3  text-natural-800 whitespace-nowrap "
              >
                <div>
                  <span className="text-sm ">{item.campaignType}</span>
                </div>
              </td>
              <td className="px-6 py-3">
                <div>
                  <span className="font-medium text-natural-700">
                    {item.lastStarted}
                  </span>
                </div>
              </td>
              <td className="px-6 py-3">
                <span className="text-sm font-medium text-natural-800">
                  {item.visitors}
                </span>
              </td>
              <td className="px-6 py-3">
                <span className="text-sm font-medium text-natural-800">
                  {item.impressions}
                </span>
              </td>
              <td className="px-6 py-3">
                <span className="text-sm font-medium text-natural-800">
                  {item.engagements}
                </span>
              </td>

              <td className="px-6 py-3">
                <ToggleButton
                  active={
                    campaignsStatus.find((cam) => cam.id === item.id).status
                  }
                  handleToggle={() => handleToggleStatus(item.id)}
                />
              </td>

              <td className="px-6 py-3">
                <Link to={item.customizeUrl} className="no-underline">
                  <CustomButton
                    icon={SettingsIcon}
                    type="ghost"
                    size="small"
                  ></CustomButton>
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CampaignTable;
