import { ActionList, Button, Icon, Popover } from '@shopify/polaris';
import { CheckSmallIcon } from '@shopify/polaris-icons';
import { useCallback, useState } from 'react';

interface LangButtonProps {
  activeLang: string;
  setActiveLang: React.Dispatch<React.SetStateAction<string>>;
}

export default function LanguageButton({
  activeLang,
  setActiveLang,
}: LangButtonProps) {
  const [active, setActive] = useState(false);

  const toggleActive = useCallback(() => setActive((active) => !active), []);

  const activator = (
    <Button onClick={toggleActive} size="large" disclosure>
      {activeLang}
    </Button>
  );

  const handleChange = (value: string) => {
    setActiveLang(value);
    setActive(false);
  };

  return (
    <div>
      <Popover
        active={active}
        activator={activator}
        autofocusTarget="first-node"
        onClose={toggleActive}
      >
        <ActionList
          items={[
            {
              content: 'Arabic (العربية)',
              suffix: activeLang === 'Arabic (العربية)' && (
                <Icon source={CheckSmallIcon} />
              ),
              onAction: () => handleChange('Arabic (العربية)'),
              active: activeLang === 'Arabic (العربية)',
            },
            {
              onAction: () => handleChange('Bengali (বাংলা)'),
              active: activeLang === 'Bengali (বাংলা)',
              content: 'Bengali (বাংলা)',
              suffix: activeLang === 'Bengali (বাংলা)' && (
                <Icon source={CheckSmallIcon} />
              ),
            },
            {
              content: 'English (English)',
              suffix: activeLang === 'English (English)' && (
                <Icon source={CheckSmallIcon} />
              ),
              onAction: () => handleChange('English (English)'),
              active: activeLang === 'English (English)',
            },
            {
              content: 'French (Français)',
              onAction: () => handleChange('French (Français)'),
              active: activeLang === 'French (Français)',
              suffix: activeLang === 'French (Français)' && (
                <Icon source={CheckSmallIcon} />
              ),
            },
            {
              content: 'German (Deutsch)',
              onAction: () => handleChange('German (Deutsch)'),
              active: activeLang === 'German (Deutsch)',
              suffix: activeLang === 'German (Deutsch)' && (
                <Icon source={CheckSmallIcon} />
              ),
            },
          ]}
        />
      </Popover>
    </div>
  );
}
