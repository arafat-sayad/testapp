import { Icon } from '@shopify/polaris';
import { ArrowRightIcon } from '@shopify/polaris-icons';
import clsx from 'clsx';

interface ItemContainerProps {
  children: JSX.Element[];
  height?: string;
  top?: string;
}

const ItemContainer = ({ children, height, top }: ItemContainerProps) => {
  const leftChild = children[0];
  const rightChild = children[1];

  return (
    <div
      className={clsx(
        'flex  justify-center gap-[84px] max-w-[644px] min-h-[142px] relative',
        `min-h-[${height}]`
      )}
      style={{ minHeight: height }}
    >
      <div className="w-1/2 min-w-[280px]">{leftChild}</div>
      <div className="w-1/2 min-w-[280px]">{rightChild}</div>

      <div
        className="flex items-center justify-center absolute top-1/2 text-natural-300"
        style={{ top }}
      >
        <Icon source={ArrowRightIcon} />
      </div>
    </div>
  );
};

export default ItemContainer;
