import { TextField } from '@shopify/polaris';
import { useCallback, useState } from 'react';
import ContentInput from '../customize/basic-settings/ContentInput';
import ItemContainer from './ItemContainer';
interface SoldProps {
  activeLang: string;
}

const SoldCountTranslation = ({ activeLang }: SoldProps) => {
  const placeholder = `Write in ${activeLang?.split(' ')[0]}`;

  const [content, setContent] = useState('');

  const [settingsValue, setSettingsValue] = useState({
    callToAction: ``,
  });

  const handleChange = useCallback(
    (newValue: string | string[], key: string) => {
      setSettingsValue((prev) => ({ ...prev, [key]: newValue }));
    },
    []
  );

  const handleContentChange = (value: string) => {
    setContent(value);
  };

  const dynamicVariables = [
    { id: '1', text: '+ OrderCount', value: '[OrderCount]' },
  ];

  return (
    <div className="flex flex-col gap-6 items-center justify-center mb-5">
      <ItemContainer top="35%">
        <ContentInput
          content={`[OrderCount] have been placed for this beautiful product`}
          dynamicVariables={dynamicVariables}
          handleContentChange={() => {}}
          title="Used variables:"
          disabled={true}
        />
        <ContentInput
          content={content}
          dynamicVariables={dynamicVariables}
          handleContentChange={handleContentChange}
          placeholder={placeholder}
        />
      </ItemContainer>

      <ItemContainer height="56px">
        <TextField
          label="Call to Action"
          value={'Buy Now'}
          onChange={(value) => {
            handleChange(value, 'callToAction');
          }}
          placeholder={`Buy now`}
          autoComplete="off"
          disabled={true}
        />
        <TextField
          label="Call to Action"
          value={settingsValue.callToAction}
          onChange={(value) => {
            handleChange(value, 'callToAction');
          }}
          placeholder={placeholder}
          autoComplete="off"
        />
      </ItemContainer>
    </div>
  );
};

export default SoldCountTranslation;
