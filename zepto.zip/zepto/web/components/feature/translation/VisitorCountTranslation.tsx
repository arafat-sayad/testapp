import { useState } from 'react';
import ContentInput from '../customize/basic-settings/ContentInput';
import ItemContainer from './ItemContainer';
interface VisitorProps {
  activeLang: string;
}

const VisitorCountTranslation = ({ activeLang }: VisitorProps) => {
  const placeholder = `Write in ${activeLang?.split(' ')[0]}`;

  const [content, setContent] = useState('');

  const handleContentChange = (value: string) => {
    setContent(value);
  };

  const dynamicVariables = [
    { id: '1', text: '+ LiveVisitor', value: '[LiveVisitor]' },
  ];

  return (
    <div className="flex flex-col gap-6 items-center justify-center mb-5">
      <ItemContainer top="35%">
        <ContentInput
          content={`[LiveVisitor] are watching this store right now`}
          dynamicVariables={dynamicVariables}
          handleContentChange={() => {}}
          title="Used variables:"
          disabled={true}
        />
        <ContentInput
          content={content}
          dynamicVariables={dynamicVariables}
          handleContentChange={handleContentChange}
          placeholder={placeholder}
        />
      </ItemContainer>
    </div>
  );
};

export default VisitorCountTranslation;
