import { TextField } from '@shopify/polaris';
import { useCallback, useState } from 'react';
import ContentInput from '../customize/basic-settings/ContentInput';
import ItemContainer from './ItemContainer';

interface SalesProps {
  activeLang: string;
}

const SalesPopTranslation = ({ activeLang }: SalesProps) => {
  const [content, setContent] = useState('');

  const [settingsValue, setSettingsValue] = useState({
    callToAction: ``,
  });

  const handleChange = useCallback(
    (newValue: string | string[], key: string) => {
      setSettingsValue((prev) => ({ ...prev, [key]: newValue }));
    },
    []
  );

  const [orderInfo, setOrderInfo] = useState({
    actualCustomers: [''],
    actualLocations: [''],
    manualCustomers: [''],
    manualLocations: [''],
  });

  const actCusVal = orderInfo.actualCustomers.join('\t');
  const actLoca = orderInfo.actualLocations.join('\t');
  const manCusVal = orderInfo.manualCustomers.join('\t');
  const manLoca = orderInfo.manualLocations.join('\t');

  const handleInfoChange = useCallback((value: string, key: string) => {
    const newText = value;
    const newTextArray = newText.split('\t');

    setOrderInfo((prev) => ({ ...prev, [key]: newTextArray }));
  }, []);

  const dynamicVariables = [
    { id: '1', text: '+ CustomerName', value: '[CustomerName]' },
    { id: '2', text: '+ Location', value: '[Location]' },
    { id: '3', text: '+ ProductTitle', value: '[ProductTitle]' },
  ];

  const handleContentChange = (value: string) => {
    setContent(value);
  };

  const placeholder = `Write in ${activeLang?.split(' ')[0]}`;
  const values = {
    CustomerName: 'John Doe',
    Location: 'New York, USA',
    ProductTitle: 'Nike Shoe',
  };

  return (
    <div className="flex flex-col gap-6 items-center justify-center mb-5">
      <ItemContainer top="35%">
        <ContentInput
          content={`[CustomerName] from [Location] just bought [ProductTitle]`}
          dynamicVariables={dynamicVariables}
          handleContentChange={() => {}}
          title="Available dynamic variables:"
          disabled={true}
        />
        <ContentInput
          content={content}
          dynamicVariables={dynamicVariables}
          handleContentChange={handleContentChange}
          placeholder={placeholder}
        />
      </ItemContainer>

      <ItemContainer height="90px">
        <TextField
          label="Fallback Customer Name"
          placeholder="Someone"
          name="actualCustomers"
          value={'Adam Smith\nJohn Doe'}
          onChange={(value) => {
            handleInfoChange(value, 'actualCustomers');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
          disabled={true}
        />

        <TextField
          label="Fallback Customer Name"
          name="actualCustomers"
          value={actCusVal}
          onChange={(value) => {
            handleInfoChange(value, 'actualCustomers');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
          placeholder={placeholder}
        />
      </ItemContainer>

      <ItemContainer height="90px">
        <TextField
          label="Fallback Location"
          placeholder="Someone"
          name="actualLocations"
          value={'New York, NY\nMiami, Florida'}
          onChange={(value) => {
            handleInfoChange(value, 'actualLocations');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
          disabled={true}
        />
        <TextField
          label="Fallback Location"
          placeholder={placeholder}
          name="actualLocations"
          value={actLoca}
          onChange={(value) => {
            handleInfoChange(value, 'actualLocations');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
        />
      </ItemContainer>

      <ItemContainer height="90px">
        <TextField
          label="Customer Name List"
          placeholder="Someone"
          name="manualCustomers"
          value={'Adam Smith\nJohn Doe\nLeonardo DiCaprio'}
          onChange={(value) => {
            handleInfoChange(value, 'manualCustomers');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
          disabled={true}
        />
        <TextField
          label="Customer Name List"
          placeholder={placeholder}
          name="manualCustomers"
          value={manCusVal}
          onChange={(value) => {
            handleInfoChange(value, 'manualCustomers');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
        />
      </ItemContainer>
      <ItemContainer height="90px">
        <TextField
          label="Location List"
          placeholder="Someone"
          name="manualLocations"
          value={'New York, NY\nMiami, Florida'}
          onChange={(value) => {
            handleInfoChange(value, 'manualLocations');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
          disabled={true}
        />
        <TextField
          label="Location List"
          placeholder={placeholder}
          name="manualLocations"
          value={manLoca}
          onChange={(value) => {
            handleInfoChange(value, 'manualLocations');
          }}
          multiline={3}
          autoComplete="off"
          inputMode="text"
        />
      </ItemContainer>
      <ItemContainer height="56px">
        <TextField
          label="Call to Action"
          value={'Buy Now'}
          onChange={(value) => {
            handleChange(value, 'callToAction');
          }}
          placeholder={`Buy now`}
          autoComplete="off"
          disabled={true}
        />
        <TextField
          label="Call to Action"
          value={settingsValue.callToAction}
          onChange={(value) => {
            handleChange(value, 'callToAction');
          }}
          placeholder={placeholder}
          autoComplete="off"
        />
      </ItemContainer>
    </div>
  );
};

export default SalesPopTranslation;
