import CartDownIcon from '@assets/icons/CartDownIcon';
import { hexToRgb } from '@shopify/polaris';
import clsx from 'clsx';

interface SoldCountCardProps {
  forMobile?: boolean;
  colors: {
    background: string;
    content: string;
    time: string;
    action: string;
  };
  template: '1' | '2' | '3' | '4' | '5';
  contents: {
    content: string;
    format: string;
    lookbackTime: string;
    callToAction: string;
  };
}

const SoldCountCard = ({
  forMobile,
  colors,
  template,
  contents,
}: SoldCountCardProps) => {
  const rgbBg = hexToRgb(colors.action);

  const templateStyles = {
    '1': {
      container: {},
      iconBg: {},
    },
    '2': {
      container: {
        borderRadius: '0px 48px 48px 40px',
        paddingRight: '28px',
      },
      iconBg: {
        borderRadius: '0px 32px 32px 32px',
      },
    },
    '3': {
      container: {
        borderRadius: '0 48px 48px 0',
        paddingRight: '24px',
        paddingLeft: '35px',
        transform: forMobile ? 'translateX(-15px)' : 'translateX(-20px)',
        minWidth: '244px',
      },
      iconBg: {
        display: 'none',
        background: 'transparent',
        position: 'relative',
        zIndex: '999999',
      },
    },
    '4': {
      container: {
        padding: '4px 28px 4px 4px',
        borderRadius: '9999px',
      },
      iconBg: {
        width: forMobile ? '64px' : '84px',
        height: forMobile ? '64px' : '84px',
        borderRadius: '9999px',
      },
    },

    '5': {
      container: {
        position: 'relative',
        zIndex: '999999',
        borderRadius: '48px 40px 0px 48px',
        gap: '20px',
      },
      iconBg: {
        width: forMobile ? '56px' : '68px',
        height: forMobile ? '56px' : '68px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        borderRadius: '9999px',
        background: colors.background,
        // border: '12px solid rgba(12, 140, 233, 0.06)',
        padding: 0,
        position: 'relative',
        zIndex: '99999',
      },
    },
  };

  return (
    <div className={clsx(template === '3' ? 'flex items-center relative' : '')}>
      {template === '3' && (
        <div
          className={clsx(
            'absolute left-0 top-1/2 -translate-y-1/2 w-[100px] h-[106px] bg-natural-25 rounded-r-full z-10',
            forMobile && '!w-[74px] !h-[76px]'
          )}
        ></div>
      )}
      {template === '3' && (
        <div
          className={clsx(
            'w-[92px] h-[92px] rounded-full relative z-50 flex items-center justify-center',
            forMobile && '!w-[80px] !h-[70px]'
          )}
          style={{
            boxShadow:
              '0px 4px 6px -2px rgba(6, 2, 10, 0.03), 0px 12px 16px -4px rgba(6, 2, 10, 0.08)',
            background: `rgba(${rgbBg.red}, ${rgbBg.green}, ${rgbBg.blue}, 0.06)`,
          }}
        >
          {forMobile ? (
            <CartDownIcon width="35" height="35" color={colors.action} />
          ) : (
            <CartDownIcon color={colors.action} />
          )}
        </div>
      )}

      <div
        className={clsx(
          'bg-white p-3 rounded-[8px] flex items-center gap-3 text-[12px] leading-5 relative min-w-[344px]',
          forMobile && 'p-[10px] text-[10px] !leading-4 !min-w-[240px]',
          templateStyles[template].container
        )}
        style={{
          boxShadow:
            '0px 4px 6px -2px rgba(6, 2, 10, 0.03), 0px 12px 16px -4px rgba(6, 2, 10, 0.08)',
          background: colors.background,
          ...(templateStyles[template]?.container || {}),
        }}
      >
        <div
          className={clsx(
            'p-[10px] bg-[rgba(189,178,201,0.06)] rounded-md flex items-center justify-center',
            forMobile && 'p-2'
          )}
          style={{
            background: `rgba(${rgbBg.red}, ${rgbBg.green}, ${rgbBg.blue}, 0.06)`,
            ...(templateStyles[template]?.iconBg || {}),
          }}
        >
          {forMobile ? (
            <CartDownIcon width="39" height="39" color={colors.action} />
          ) : (
            <CartDownIcon color={colors.action} />
          )}
        </div>

        <div className="flex flex-col justify-between gap-2">
          <div
            className={clsx(
              'max-w-[240px]',
              forMobile && 'max-w-[190px] text-[11px]'
            )}
          >
            <p className="text-natural-800" style={{ color: colors.content }}>
              <span dangerouslySetInnerHTML={{ __html: contents.content }} />
            </p>
          </div>
          <div
            className={clsx(
              'flex items-center justify-between text-xs',
              forMobile && '!text-[11px]'
            )}
          >
            <span style={{ color: colors.time }}>
              In last {contents.lookbackTime} {contents.format}
            </span>
            <span
              className={clsx(
                'font-medium text-primary flex items-center text-xs',
                forMobile && '!text-[11px]'
              )}
              style={{ color: colors.action }}
            >
              {contents.callToAction}
            </span>
          </div>
        </div>

        {template === '5' && (
          <div
            className={clsx(
              'absolute left-0 w-[92px] h-[92px] rounded-full z-[99]',
              forMobile && '!w-[72px] !h-[72px]'
            )}
            style={{
              background: `rgba(${rgbBg.red}, ${rgbBg.green}, ${rgbBg.blue}, 0.06)`,
            }}
          ></div>
        )}

        {/* {template === '3' && (
        <div className="absolute left-2 top-0 w-[100px] h-[100px] rounded-full bg-natural-25 shadow-none z-[9]"></div>
      )} */}
      </div>
    </div>
  );
};

export default SoldCountCard;
