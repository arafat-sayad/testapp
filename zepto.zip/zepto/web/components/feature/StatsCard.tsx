import { Box, Card, Icon, InlineStack, Text, Tooltip } from '@shopify/polaris';
import { QuestionCircleIcon } from '@shopify/polaris-icons';
import { CountUp } from 'use-count-up';

interface StatsCardProps {
  title: string;
  icon: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
  count: number;
  name: string;
  toltipContent: string;
}

const StatsCard = ({
  title,
  icon,
  count,
  name,
  toltipContent,
}: StatsCardProps) => {
  return (
    <Card>
      <InlineStack
        as="div"
        direction={'row'}
        blockAlign="center"
        align="space-between"
      >
        <InlineStack gap="100">
          <Icon source={icon} tone="base" />
          <div className="text-base font-medium">
            <Text as="h4">{title}</Text>
          </div>
        </InlineStack>

        <div className="cursor-pointer">
          <Tooltip content={toltipContent}>
            <Icon source={QuestionCircleIcon} tone="base" />
          </Tooltip>
        </div>
      </InlineStack>
      <Box as="div" paddingBlockStart={'500'}>
        <InlineStack gap="200" blockAlign="center">
          <Text as="h4" variant="headingXl" fontWeight="medium">
            <CountUp isCounting end={count} duration={2} />
          </Text>
          <Text as="span" variant="bodyLg">
            {name}
          </Text>
        </InlineStack>
      </Box>
    </Card>
  );
};

export default StatsCard;
