import { BlockStack, Card, InlineStack, Text } from '@shopify/polaris';
import { useState } from 'react';
import { Link } from 'react-router-dom';

import { SettingsIcon } from '@shopify/polaris-icons';
import { PopupType, ToggleCampaignReq } from '@type/index';
import CustomButton from '../ui/CustomButton';
import ToggleButton from './ToggleButton';
interface CampaignCardProps {
  image: JSX.Element;
  title: string;
  description: string;
  link: string;
  status: boolean;
  handleToggle: (data: ToggleCampaignReq) => void;
  popup_type: PopupType;
}

const CampaignCard = ({
  image,
  title,
  description,
  link,
  status,
  popup_type,
  handleToggle,
}: CampaignCardProps) => {
  const [activeCustomize, setActiveCustomize] = useState(status);

  const handleStatusToggle = () => {
    setActiveCustomize((prev) => !prev);
    handleToggle({
      popupType: popup_type,
      body: { status: activeCustomize ? 0 : 1 },
    });
  };

  return (
    <Card>
      <BlockStack gap="400">
        <div className="bg-primary-25 rounded-[8px] min-h-[214px] flex flex-col items-center justify-center">
          {image}
        </div>
        <BlockStack gap="100">
          <div className="text-natural-900">
            <Text as="h3" variant="headingMd">
              {title}
            </Text>
          </div>

          <div className="leading-5 text-natural-800">
            <Text as="p" variant="bodyMd">
              {description}
            </Text>
          </div>
        </BlockStack>

        <InlineStack
          as="div"
          wrap={false}
          align="space-between"
          blockAlign="center"
        >
          <Link to={link} className="no-underline">
            <CustomButton
              size="small"
              className="!text-xs py-[5px] px-3 !gap-[2px]"
              type="primary"
              icon={SettingsIcon}
            >
              Customize
            </CustomButton>
          </Link>
          <ToggleButton
            active={activeCustomize}
            handleToggle={handleStatusToggle}
          />
        </InlineStack>
      </BlockStack>
    </Card>
  );
};

export default CampaignCard;
