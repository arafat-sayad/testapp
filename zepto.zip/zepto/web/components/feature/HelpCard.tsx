import { Box, Card, InlineStack, Text } from '@shopify/polaris';

interface HelpCardProps {
  title: string;
  content: string;
  icon: JSX.Element;
  // | React.FunctionComponent<React.SVGProps<SVGSVGElement>>
  // | 'placeholder'
  // | string;
}

const HelpCard = ({ title, content, icon }: HelpCardProps) => {
  return (
    <Card>
      <div className="flex pb-2 justify-start text-left">
        <InlineStack>
          <div className="text-natural-800 help-icon ">{icon}</div>
        </InlineStack>
      </div>

      <Box paddingBlockEnd={'200'}>
        <div className="text-natural-900">
          <Text as="h3" fontWeight="medium" variant="headingMd">
            {title}
          </Text>
        </div>
        <div className="text-natural-800 pt-1 leading-6">
          <Text as="p" variant="bodySm">
            {content}
          </Text>
        </div>
      </Box>
    </Card>
  );
};

export default HelpCard;
