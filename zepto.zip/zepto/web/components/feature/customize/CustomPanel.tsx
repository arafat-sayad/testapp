import TabButton from '@components/ui/TabButton';
import { Card, InlineStack } from '@shopify/polaris';
import { SettingsIcon, WandIcon } from '@shopify/polaris-icons';
import { useState } from 'react';

interface CustomPanelProps {
  stylesContent: JSX.Element;
  children: React.ReactNode;
}

const CustomPanel = ({ stylesContent, children }: CustomPanelProps) => {
  const [activeTab, setActiveTab] = useState<'settings' | 'styles'>('settings');

  const handleTabChange = (value: 'settings' | 'styles') => () => {
    setActiveTab(value);
  };

  return (
    <Card>
      <InlineStack as="div" align="space-between" blockAlign="center">
        <TabButton
          icon={SettingsIcon}
          active={activeTab === 'settings'}
          onClick={handleTabChange('settings')}
        >
          Settings
        </TabButton>
        <TabButton
          icon={WandIcon}
          active={activeTab === 'styles'}
          onClick={handleTabChange('styles')}
        >
          Styles
        </TabButton>
      </InlineStack>
      {activeTab === 'settings' && children}
      {activeTab === 'styles' && stylesContent}
    </Card>
  );
};

export default CustomPanel;
