import useClickOutside from '@hooks/useClickOutside';
import {
  ColorPicker,
  Text,
  hexToRgb,
  hsbToHex,
  rgbToHsb,
} from '@shopify/polaris';
import clsx from 'clsx';
import { ChangeEvent, useEffect, useRef, useState } from 'react';

interface ColorPickerProps {
  color: string;
  onChange: (
    key: 'background' | 'content' | 'time' | 'action',
    value: string
  ) => void;
  text: string;
  name: 'background' | 'content' | 'time' | 'action';
  left?: boolean;
  activeTemplate?: string;
}

const hexToHsb = (hex: string) => {
  const rbg = hexToRgb(hex);
  return rgbToHsb(rbg);
};

const ColorPickerInput = ({
  text,
  color: inputColor,
  onChange,
  name,
  left,
  activeTemplate,
}: ColorPickerProps) => {
  const [showPicker, setShowPicker] = useState(false);
  const handleClick = () => setShowPicker(!showPicker);
  const pickerRef = useRef(null);

  const initialColor = hexToHsb(inputColor);

  const [color, setColor] = useState({
    hue: initialColor.hue,
    brightness: initialColor.brightness,
    saturation: initialColor.saturation,
  });

  useClickOutside(pickerRef, handleClick);

  useEffect(() => {
    onChange(name, hsbToHex(color));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [color]);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onChange(name, value);
  };

  const handleBlur = () => {
    setColor({
      hue: initialColor.hue,
      brightness: initialColor.brightness,
      saturation: initialColor.saturation,
    });
  };

  useEffect(() => {
    setColor({
      hue: initialColor.hue,
      brightness: initialColor.brightness,
      saturation: initialColor.saturation,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTemplate]);

  return (
    <div className="relative h-full">
      <div className="text-natural-700 pb-1">
        <Text as="h4" variant="headingSm" fontWeight="regular">
          {text}
        </Text>
      </div>
      <div className="flex gap-1 items-center py-[8px] px-[10px] rounded-md border border-natural-100">
        <div className="flex items-center">
          <button
            className="w-5 h-5 border border-natural-50  rounded-[5px]  shadow-xs"
            style={{ background: hsbToHex(color) }}
            onClick={handleClick}
          ></button>
        </div>
        <div className="text-natural-900 relative">
          <input
            value={inputColor}
            onChange={handleInputChange}
            type="text"
            name={name}
            className="w-[90px] text-sm  focus:outline-none uppercase"
            onBlur={handleBlur}
          />
          {/* <span className="absolute left-0 top-1/2 -translate-y-1/2">#</span> */}
        </div>
      </div>

      {showPicker && (
        <div
          className={clsx(
            'absolute top-full right-0  z-[999] w-[215px] h-[190px] bg-white border border-natural-100 rounded-lg shadow-lg flex items-center justify-center',
            left && '!left-0'
          )}
          ref={pickerRef}
        >
          <ColorPicker onChange={setColor} color={color} />
        </div>
      )}
    </div>
  );
};

export default ColorPickerInput;
