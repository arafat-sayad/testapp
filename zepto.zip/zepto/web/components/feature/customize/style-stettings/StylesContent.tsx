import { colorPickerData, templates } from '@constants/styleSettings';
import { BlockStack, Box, Text } from '@shopify/polaris';
import { CampaignCustomizeInterface as Types } from '@type/index';

import ColorPickerInput from './ColorPickerInput';

interface StylesContentProps {
  colors: Types['colors'];
  activeTemplate: Types['activeTemplate'];
  handleHexChange: Types['handleHexChange'];
  handleActiveChange: Types['handleActiveChange'];
}

const StylesContent = ({
  colors,
  activeTemplate,
  handleHexChange,
  handleActiveChange,
}: StylesContentProps) => {
  return (
    <Box paddingBlockStart="600">
      <div className="grid grid-cols-2 gap-2 ">
        {colorPickerData.map((item, index) => (
          <ColorPickerInput
            key={item.id}
            name={item.name}
            color={colors[item.name]}
            onChange={handleHexChange}
            text={item.text}
            left={index === 0 || index === 2}
            activeTemplate={activeTemplate}
          />
        ))}
      </div>

      <Box paddingBlockStart={'400'}>
        <div className="text-natural-700 pb-1">
          <Text as="h4" variant="headingSm" fontWeight="regular">
            Templates
          </Text>
        </div>
        <BlockStack gap={'300'}>
          {templates.map(({ key, Template }) => (
            <Template
              key={key}
              active={activeTemplate === key}
              onClick={() => handleActiveChange(key)}
            />
          ))}
        </BlockStack>
      </Box>
    </Box>
  );
};

export default StylesContent;
