import PreviewIcon from '@assets/icons/PreviewIcon';
import CustomButton from '@components/ui/CustomButton';
import TabButton from '@components/ui/TabButton';
import { Box, Card, InlineStack, Text } from '@shopify/polaris';
import { DesktopIcon, MobileIcon } from '@shopify/polaris-icons';
import clsx from 'clsx';

interface PreviewSectionProps {
  activeTemplate: '3' | '1' | '2' | '4' | '5';
  view: 'mobile' | 'desktop';
  toggleView: (view: 'mobile' | 'desktop') => void;
  desktopPosition: 'bottom-left' | 'top-left' | 'bottom-right' | 'top-right';
  mobilePosition: 'top' | 'bottom';
  previewCard: JSX.Element;
}

const PreviewSection = ({
  activeTemplate,
  view,
  toggleView,
  desktopPosition,
  mobilePosition,
  previewCard,
}: PreviewSectionProps) => {
  const deskPositionStyles = {
    'bottom-left': 'bottom-5 left-5',
    'top-left': 'top-5 left-5',
    'bottom-right':
      activeTemplate === '3' ? 'bottom-5 right-0' : 'bottom-5 right-5',
    'top-right': activeTemplate === '3' ? 'top-5 right-0' : 'top-5 right-5',
  };

  const mobPositionsStyles = {
    top: 'top-5',
    bottom: 'bottom-5',
  };

  return (
    <Card>
      <InlineStack as="div" align="space-between" blockAlign="center">
        <div className="w-[55%] text-natural-900">
          <Text as="h4" variant="headingMd" fontWeight="medium">
            Preview Section
          </Text>
        </div>
        <div className="w-[45%] flex items-center justify-between">
          <InlineStack as="div" align="space-between" blockAlign="center">
            <TabButton
              icon={DesktopIcon}
              active={view === 'desktop'}
              onClick={() => toggleView('desktop')}
            ></TabButton>
            <TabButton
              icon={MobileIcon}
              active={view === 'mobile'}
              onClick={() => toggleView('mobile')}
            ></TabButton>
          </InlineStack>
          <Box as="div">
            <CustomButton
              className="w-full h-[32px] gap-[1px] text-xs"
              type="neutral"
              suffixIcon={<PreviewIcon />}
            >
              View in Shop
            </CustomButton>
          </Box>
        </div>
      </InlineStack>

      <div className="w-full flex items-center justify-center">
        <div
          className={clsx(
            'w-full  bg-natural-25 rounded-md flex items-center justify-center h-[720px] mt-5 relative',
            view === 'mobile' && '!w-[55%]'
          )}
        >
          <h2 className="text-2xl text-primary-100 ">Preview</h2>
          {view === 'desktop' ? (
            <div
              className={clsx(
                'absolute z-10',
                deskPositionStyles[desktopPosition]
              )}
            >
              {previewCard}
              {/* <PreviewCard template={activeTemplate} colors={colors} /> */}
            </div>
          ) : (
            <div
              className={clsx(
                'absolute left-5 right-5  z-10',
                mobPositionsStyles[mobilePosition]
              )}
            >
              {/* <PreviewCard
                template={activeTemplate}
                forMobile={true}
                colors={colors}
              /> */}
              {previewCard}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default PreviewSection;
