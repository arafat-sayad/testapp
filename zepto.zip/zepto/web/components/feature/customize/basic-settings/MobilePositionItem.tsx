import { Text } from '@shopify/polaris';
import clsx from 'clsx';
interface MobilePosition {
  position: 'bottom' | 'top';
}

interface MobilePositionProps extends MobilePosition {
  isActive: boolean;
  text: string;
  onClick: (position: MobilePosition['position']) => void;
}

const MobilePositionItem = ({
  isActive,
  text,
  position,
  onClick,
}: MobilePositionProps) => {
  const positionStyles = {
    top: 'top-2',
    bottom: 'bottom-2',
  };
  return (
    <button onClick={() => onClick(position)}>
      <div
        className={clsx(
          'w-[70px] h-[120px] relative border-[0.094rem] border-natural-100 rounded-md shadow-sm',
          isActive && 'border-primary'
        )}
      >
        <div
          className={clsx(
            'absolute left-1/2 -translate-x-1/2  bg-natural-50 w-[56px] h-4 rounded-[4px]',
            positionStyles[position],
            isActive && 'bg-primary-200'
          )}
        ></div>
      </div>
      <div className="text-natural-700 leading-5 pt-[2px]">
        <Text variant="bodySm" as="span" alignment="center">
          {text}
        </Text>
      </div>
    </button>
  );
};

export default MobilePositionItem;
