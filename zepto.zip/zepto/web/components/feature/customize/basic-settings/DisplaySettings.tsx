import AccordionButton from '@components/ui/AccordionButton';
import { displayPageOpt } from '@constants/index';
import {
  BlockStack,
  Box,
  Collapsible,
  Select,
  Text,
  TextField,
} from '@shopify/polaris';
import { CampaignCustomizeInterface as Types } from '@type/index';
import { useCallback, useState } from 'react';

interface DisplaySettingsProps {
  settingsValue: Types['displaySettings'];
  handleChange: Types['handleDisplayChange'];
}

const DisplaySettings = ({
  settingsValue,
  handleChange,
}: DisplaySettingsProps) => {
  const [open, setOpen] = useState(true);

  const handleToggle = useCallback(() => setOpen((open) => !open), []);

  const showDisplayPagelink =
    settingsValue.dispayPage == 'folling-url' ||
    settingsValue.dispayPage == 'only-page-url' ||
    settingsValue.dispayPage == 'any-page-url';

  return (
    <>
      <AccordionButton open={open} onClick={handleToggle}>
        Display Settings
      </AccordionButton>

      <Collapsible
        open={open}
        id="basic-collapsible"
        transition={{ duration: '300ms', timingFunction: 'ease-in-out' }}
        expandOnPrint
      >
        <BlockStack gap={'400'}>
          <TextField
            label="Before Showing Time"
            type="number"
            placeholder="10 seconds"
            value={settingsValue.beforeTime}
            onChange={(value) => {
              handleChange(value, 'beforeTime');
            }}
            autoComplete="off"
          />

          <TextField
            label="After Staying Time"
            type="number"
            placeholder="10 seconds"
            value={settingsValue.afterTime}
            onChange={(value) => {
              handleChange(value, 'afterTime');
            }}
            autoComplete="off"
          />

          <Box as="div">
            <Select
              label="Display Page"
              options={displayPageOpt}
              value={settingsValue.dispayPage}
              onChange={(value) => {
                handleChange(value, 'dispayPage');
              }}
            />
            {showDisplayPagelink && (
              <div className=" text-natural-700">
                <Text as="span" variant="bodyXs">
                  Separate with enter ↩ for multiple names
                </Text>
              </div>
            )}
          </Box>

          {showDisplayPagelink ? (
            <>
              <TextField
                label=""
                placeholder="https://yourstore.myshopify.com/your-page"
                value={settingsValue.link}
                onChange={(value) => {
                  handleChange(value, 'link');
                }}
                multiline={3}
                autoComplete="off"
                inputMode="text"
              />
            </>
          ) : null}
        </BlockStack>
      </Collapsible>
    </>
  );
};

export default DisplaySettings;
