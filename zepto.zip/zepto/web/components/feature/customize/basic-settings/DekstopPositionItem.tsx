import { Text } from '@shopify/polaris';
import clsx from 'clsx';

interface PositionProps {
  position: 'bottom-left' | 'top-left' | 'bottom-right' | 'top-right';
}

interface DekstopPositionProps extends PositionProps {
  isActive: boolean;
  text: string;
  onClick: (position: PositionProps['position']) => void;
}

const DekstopPositionItem = ({
  isActive,
  text,
  position,
  onClick,
}: DekstopPositionProps) => {
  const positionStyles = {
    'bottom-left': 'left-2 bottom-2',
    'bottom-right': 'right-2 bottom-2',
    'top-left': 'top-2 left-2',
    'top-right': 'top-2 right-2',
  };

  return (
    <button onClick={() => onClick(position)}>
      <div
        className={clsx(
          'w-[134px] h-[64px] border-[1.5px] border-natural-100 rounded-md relative mb-1',
          isActive && 'border-primary'
        )}
      >
        <div
          className={clsx(
            'absolute z-10 w-10 h-4 bg-natural-50 rounded-[4px] shadow-sm',
            positionStyles[position],
            isActive && 'bg-primary-200'
          )}
        ></div>
      </div>
      <div className="text-sm text-natural-700">
        <Text variant="bodySm" as="span" alignment="center">
          {text}
        </Text>
      </div>
    </button>
  );
};

export default DekstopPositionItem;
