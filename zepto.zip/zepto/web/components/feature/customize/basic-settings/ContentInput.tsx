import { Box } from '@shopify/polaris';
import { CampaignCustomizeInterface as Types } from '@type/index';
import clsx from 'clsx';
import { useRef } from 'react';

interface ContentInputProps {
  content: Types['content'];
  handleContentChange: Types['handleContentChange'];
  dynamicVariables: {
    id: string;
    text: string;
    value: string;
  }[];
  title?: string;
  disabled?: boolean;
  placeholder?: string;
}

const ContentInput = ({
  content,
  handleContentChange,
  dynamicVariables,
  title = 'Available dynamic variables:',
  disabled,
  placeholder,
}: ContentInputProps) => {
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  const handleInsertText = (text: string) => {
    if (textAreaRef.current) {
      const { selectionStart, selectionEnd } = textAreaRef.current;
      const newValue =
        content.substring(0, selectionStart) +
        text +
        content.substring(selectionEnd, content.length);
      handleContentChange(newValue);

      // Set cursor position after inserted text
      if (textAreaRef.current) {
        textAreaRef.current.selectionStart = selectionStart + text.length;
        textAreaRef.current.selectionEnd = selectionStart + text.length;
        textAreaRef.current.focus();
      }
    }
  };

  let showDynamic = false;

  dynamicVariables.map((obj) => {
    if (!content.includes(obj.value)) {
      return (showDynamic = true);
    }
  });

  if (disabled) showDynamic = true;

  return (
    <Box>
      <Box>
        <label
          htmlFor="content"
          className={clsx(disabled && 'text-[#b5b5b5] text-[13px] font-medium')}
        >
          Content Text
        </label>
        <textarea
          ref={textAreaRef}
          value={content}
          id="content"
          name="content"
          placeholder={placeholder}
          className={clsx(
            'border border-[rgb(48,48,48)]  leading-[1.25rem] rounded-md focus:outline-none focus:ring-[2px]  focus:ring-blue-500 p-2 w-full !h-[90px] overflow-y-auto resize-none',
            disabled && 'text-natural-300 bg-natural-25 border-none'
          )}
          onChange={(e) => {
            handleContentChange(e.target.value);
          }}
          disabled={disabled}
        />
      </Box>

      {showDynamic && (
        <div className="flex flex-wrap items-center gap-[6px] mt-1">
          <span
            className={clsx(
              'text-primary text-xs',
              disabled && 'text-primary-300'
            )}
          >
            {title}
          </span>
          <div className="flex items gap-1 ">
            {dynamicVariables.map((variable) => (
              <>
                {disabled ? (
                  <button
                    className={clsx(
                      'bg-primary px-2 py-1 text-white rounded-xl text-[10px] font-medium',
                      disabled && 'cursor-default bg-primary-200'
                    )}
                    onClick={() => handleInsertText(variable.value)}
                    disabled={disabled}
                  >
                    {variable.text}
                  </button>
                ) : (
                  <>
                    {!content.includes(variable.value) && (
                      <button
                        className="bg-primary px-2 py-1 text-white rounded-xl text-[10px] font-medium"
                        onClick={() => handleInsertText(variable.value)}
                      >
                        {variable.text}
                      </button>
                    )}
                  </>
                )}
              </>
            ))}
          </div>
        </div>
      )}
    </Box>
  );
};

export default ContentInput;
