import AccordionButton from '@components/ui/AccordionButton';
import { dekstopItemData, mobileItemData } from '@constants/index';
import {
  BlockStack,
  Box,
  Collapsible,
  InlineStack,
  Text,
} from '@shopify/polaris';
import { CampaignCustomizeInterface as Types } from '@type/index';
import { useCallback, useState } from 'react';
import ToggleButton from '../../ToggleButton';
import DekstopPositionItem from './DekstopPositionItem';
import MobilePositionItem from './MobilePositionItem';

interface PositionSettingsProps {
  mobilePosition: Types['mobilePosition'];
  desktopPosition: Types['desktopPosition'];
  toggleDesktopPosition: Types['toggleDesktopPosition'];
  toggleMobilePosition: Types['toggleMobilePosition'];
  activeMobile: Types['activeMobile'];
  toggleActiveMobile: Types['toggleActiveMobile'];
}

const PositionSettings = ({
  mobilePosition,
  desktopPosition,
  toggleDesktopPosition,
  toggleMobilePosition,
  activeMobile,
  toggleActiveMobile,
}: PositionSettingsProps) => {
  const [positionOpen, setPositionOpen] = useState(false);
  const handlePositonToggle = useCallback(
    () => setPositionOpen((open) => !open),
    []
  );

  return (
    <>
      <AccordionButton open={positionOpen} onClick={handlePositonToggle}>
        Position
      </AccordionButton>

      <Collapsible
        open={positionOpen}
        id="basic-collapsible"
        transition={{ duration: '300ms', timingFunction: 'ease-in-out' }}
        expandOnPrint
      >
        {/* Dekstop Position */}
        <BlockStack gap={'400'}>
          <Box>
            <span className="text-xs text-natural-700">Desktop Position</span>
            <div className="grid grid-cols-2 mt-2 gap-3">
              {dekstopItemData.map((item) => (
                <DekstopPositionItem
                  key={item.id}
                  position={item.position}
                  isActive={desktopPosition === item.position}
                  text={item.text}
                  onClick={toggleDesktopPosition}
                />
              ))}
            </div>
          </Box>

          {/* Mobile Position */}
          <BlockStack as="div" gap={'300'}>
            <InlineStack blockAlign="center" gap={'150'}>
              <div className="text-natural-700">
                <Text as="span" variant="bodyMd">
                  Mobile Position
                </Text>
              </div>
              <ToggleButton
                size="small"
                className="px-[2px] !w-[30px] h-[16px]"
                active={activeMobile}
                handleToggle={toggleActiveMobile}
              />
            </InlineStack>

            {activeMobile && (
              <InlineStack as="div" blockAlign="center" gap={'300'}>
                {mobileItemData.map((item) => (
                  <MobilePositionItem
                    key={item.id}
                    position={item.position}
                    isActive={mobilePosition === item.position}
                    text={item.text}
                    onClick={toggleMobilePosition}
                  />
                ))}
              </InlineStack>
            )}
          </BlockStack>
        </BlockStack>
      </Collapsible>
    </>
  );
};

export default PositionSettings;
