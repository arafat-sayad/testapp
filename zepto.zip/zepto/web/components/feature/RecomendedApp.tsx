import { BlockStack, Box, InlineStack, Text } from '@shopify/polaris';

interface RecomendedAppProps {
  image: string;
  title: string;
  content: string;
  linkText: string;
  link?: string;
}

const RecomendedApp = ({
  image,
  title,
  content,
  linkText,
  link = '',
}: RecomendedAppProps) => {
  return (
    <a href={link} target="_blank" className="no-underline text-natural-900">
      <div className="border border-primary-100 rounded-xl p-3 cursor-pointer transition-all duration-200 hover:shadow-md">
        <Box as="div">
          <InlineStack as="div" wrap={false} gap="300" direction={'row'}>
            <Box>
              <img src={image} alt={title} width={80} height={80} />
            </Box>
            <Box>
              <BlockStack gap="050">
                <Text as="h4" variant="headingMd" fontWeight="medium">
                  {title}
                </Text>
                <p className="text-xs leading-5 text-natural-800">{content}</p>

                <span className="text-[11px] text-warning-500 no-underline">
                  {linkText}
                </span>
              </BlockStack>
            </Box>
          </InlineStack>
        </Box>
      </div>
    </a>
  );
};

export default RecomendedApp;
