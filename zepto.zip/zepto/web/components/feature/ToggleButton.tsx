import { clsx } from 'clsx';

interface ToggleButtonProps {
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  className?: string;
  active: boolean;
  handleToggle: () => void;
}

const ToggleButton = ({
  size = 'medium',
  active,
  handleToggle,
  className,
}: ToggleButtonProps) => {
  const sizes = {
    small: 'w-[26px] h-[14px] p-[0.094rem]',
    medium: 'w-[36px] h-5 p-[2px]',
    large: 'w-11 h-6 p-[2px]',
  };

  const circles = {
    small: 'w-[12px] h-[12px]',
    medium: 'w-4 h-4',
    large: 'w-5 h-5',
  };

  return (
    <button
      onClick={handleToggle}
      className={clsx(
        sizes[size],
        'rounded-full  bg-natural-50 flex items-center justify-start cursor-pointer transition-all duration-300 p-[1px] hover:bg-natural-100',
        className,
        active && 'justify-end !bg-primary'
      )}
    >
      <div
        className={clsx('rounded-full bg-white', circles[size])}
        style={{
          boxShadow:
            '0px 1px 2px 0px rgba(16, 24, 40, 0.06), 0px 1px 3px 0px rgba(16, 24, 40, 0.10);',
        }}
      ></div>
    </button>
  );
};

export default ToggleButton;
