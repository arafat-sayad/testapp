import { Grid } from '@shopify/polaris';

interface CampCustLayoutProps {
  pageTitle: string;
  children: JSX.Element[];
}

const CampCustLayout = ({ pageTitle, children }: CampCustLayoutProps) => {
  const leftChildren = children[0];
  const rightChildren = children[1];

  return (
    <>
      <div id="sold_count">
        {/* <PageTitle>{pageTitle}</PageTitle> */}

        <Grid gap={{ md: '400' }}>
          <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 4, lg: 4, xl: 4 }}>
            {leftChildren}
          </Grid.Cell>
          <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 6, lg: 8, xl: 8 }}>
            {rightChildren}
          </Grid.Cell>
        </Grid>
      </div>
    </>
  );
};

export default CampCustLayout;
