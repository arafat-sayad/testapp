// <--- Run in admin mode --->

// import react from '@vitejs/plugin-react';
// import dotenv from 'dotenv';
// import { dirname, resolve } from 'path';
// import { fileURLToPath } from 'url';
// import { defineConfig } from 'vite';
// dotenv.config();

// if (
//   process.env.npm_lifecycle_event === 'build' &&
//   !process.env.CI &&
//   !process.env.SHOPIFY_API_KEY
// ) {
//   console.warn(
//     '\nBuilding the frontend app without an API key. The frontend build will not run without an API key. Set the SHOPIFY_API_KEY environment variable when running the build command.\n'
//   );
// }

// const proxyOptions = {
//   target: `http://127.0.0.1:${process.env.BACKEND_PORT}`,
//   changeOrigin: false,
//   secure: true,
//   ws: false,
// };

// const host = process.env.HOST
//   ? process.env.HOST.replace(/https?:\/\//, '')
//   : 'localhost';

// let hmrConfig;
// if (host === 'localhost') {
//   hmrConfig = {
//     protocol: 'ws',
//     host: 'localhost',
//     port: 64999,
//     clientPort: 64999,
//   };
// } else {
//   hmrConfig = {
//     protocol: 'wss',
//     host: host,
//     port: process.env.FRONTEND_PORT,
//     clientPort: 443,
//   };
// }

// export default defineConfig({
//   root: dirname(fileURLToPath(import.meta.url)),
//   plugins: [react()],
//   define: {
//     // 'process.env': process.env,
//     'process.env.SHOPIFY_API_KEY': JSON.stringify(process.env.SHOPIFY_API_KEY),
//   },
//   resolve: {
//     preserveSymlinks: true,
//     alias: {
//       '@components': resolve(__dirname, 'components'), // Assuming your components are in a 'components' folder
//       // Add other aliases as needed
//       '@assets': resolve(__dirname, 'assets'),
//       '@hooks': resolve(__dirname, 'hooks'),
//       '@utils': resolve(__dirname, 'utils'),
//       '@views': resolve(__dirname, 'views'),
//       '@providers': resolve(__dirname, 'providers'),
//       '@constants': resolve(__dirname, 'constants'),
//       '@type': resolve(__dirname, 'type'),
//       '@services': resolve(__dirname, 'services'),

//       // Add more aliases as per your project structure
//     },
//   },
//   server: {
//     host: 'localhost',
//     port: process.env.FRONTEND_PORT,
//     hmr: hmrConfig,
//     proxy: {
//       '^/(\\?.*)?$': proxyOptions,
//       '^/api(/|(\\?.*)?$)': proxyOptions,
//     },
//   },
// });

// <---- Run in Local Mode ----->
import react from '@vitejs/plugin-react';
import dotenv from 'dotenv';
import { resolve } from 'path';
import { defineConfig } from 'vite';

dotenv.config();

export default defineConfig({
  plugins: [react()],
  resolve: {
    preserveSymlinks: true,
    alias: {
      '@components': resolve(__dirname, 'components'), // Assuming your components are in a 'components' folder
      // Add other aliases as needed
      '@assets': resolve(__dirname, 'assets'),
      '@hooks': resolve(__dirname, 'hooks'),
      '@utils': resolve(__dirname, 'utils'),
      '@views': resolve(__dirname, 'views'),
      '@providers': resolve(__dirname, 'providers'),
      '@constants': resolve(__dirname, 'constants'),
      '@type': resolve(__dirname, 'type'),
      '@services': resolve(__dirname, 'services'),
      // Add more aliases as per your project structure
    },
  },
  define: {
    'process.env': process.env,
  },
  server: {
    port: process.env.FRONTEND_PORT,
  },
  preview: {
    port: 3000,
    strictPort: true,
    host: true,
  },
});
