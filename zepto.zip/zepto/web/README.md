# **Shopify Zepto Popup Manager**

This repository contains the frontend application for a Shopify app developed using React TypeScript, Tailwind CSS, Yarn, Shopify App Bridge, and Polaris technologies.

## **Environment Variables**

To run the project, ensure you have a **`.env`** file in the root directory with the following environment variables:

```
dotenvCopy code
ENVIRONMENT=
SHOPIFY_API_KEY=
SHOPIFY_API_SECRET=
SHOPIFY_HOST=
TEST_TOKEN=
LOCAL_MODE=true
```

Replace the placeholders with your specific configuration details. Note that to fully test and run the project, you'll need to target a specific Shopify store and provide the appropriate Shopify API credentials.

## **Getting Started**

1. Clone this repository to your local machine.
2. Install dependencies using Yarn:

   ```bash
   yarn instal
   ```

3. Ensure that your **`.env`** file is properly configured as mentioned above.
4. Start the development server:

   ```bash

   yarn dev
   ```

5. The application will run in "local mode," meaning it will simulate interactions with a Shopify store locally. However, for full functionality, you'll need to deploy the app to a Shopify store environment.

## **Deploying to Shopify Store**

To deploy the app to a Shopify store environment, follow these steps:

1. **Create a Shopify App**: Create an app in the Shopify Partner Dashboard and obtain your API key and secret.
2. **Set Up Environment Variables**: Update the **`.env`** file with your Shopify API credentials and configure the **`SHOPIFY_HOST`** variable to point to your Shopify store.
3. **Deploy to a Shopify Store**: Follow Shopify's documentation to deploy your app to a development store or a live store.
4. **Test**: Once deployed, test the app's functionality on your Shopify store to ensure everything works as expected.

## **Available Scripts**

In the project directory, you can run:

- **`yarn start`**: Starts the development server.
- **`yarn build`**: Builds the app for production.
- **`yarn test`**: Launches the test runner.
- **`yarn lint`**: Runs ESLint for code linting.
- **`yarn format`**: Formats code using Prettier.

## **Contributing**

Contributions are welcome! Please follow our [Contribution Guidelines](https://chat.openai.com/c/CONTRIBUTING.md) when making changes to this project.

## **License**

This project is licensed under the MIT License. See the LICENSE file for details.
