const ChevronRight = ({ color = '#391363' }: { color: string }) => {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M6.9477 13.0772C6.6841 12.8136 6.6841 12.3862 6.9477 12.1226L10.0704 8.9999L6.9477 5.8772C6.6841 5.6136 6.6841 5.18621 6.9477 4.92261C7.21131 4.659 7.63869 4.659 7.9023 4.92261L11.5023 8.52261C11.7659 8.78621 11.7659 9.2136 11.5023 9.4772L7.9023 13.0772C7.63869 13.3408 7.21131 13.3408 6.9477 13.0772Z"
        fill={color}
      />
    </svg>
  );
};

export default ChevronRight;
