const Template5 = ({
  active,
  onClick,
}: {
  active?: boolean;
  onClick?: () => void;
}) => {
  return (
    <button onClick={onClick}>
      <svg
        width="282"
        height="79"
        viewBox="0 0 282 79"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <mask id="path-1-inside-1_920_6846" fill="white">
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M39.5 0C17.6848 0 0 17.6848 0 39.5C0 61.3152 17.6848 79 39.5 79C43.8477 79 48.0314 78.2976 51.9437 77H282V22C282 10.9543 273.046 2 262 2H51.9437C48.0314 0.702432 43.8477 0 39.5 0Z"
          />
        </mask>
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M39.5 0C17.6848 0 0 17.6848 0 39.5C0 61.3152 17.6848 79 39.5 79C43.8477 79 48.0314 78.2976 51.9437 77H282V22C282 10.9543 273.046 2 262 2H51.9437C48.0314 0.702432 43.8477 0 39.5 0Z"
          fill="white"
        />
        <path
          d="M51.9437 77V75.5H51.7015L51.4715 75.5763L51.9437 77ZM282 77V78.5H283.5V77H282ZM51.9437 2L51.4715 3.42374L51.7015 3.5H51.9437V2ZM1.5 39.5C1.5 18.5132 18.5132 1.5 39.5 1.5V-1.5C16.8563 -1.5 -1.5 16.8563 -1.5 39.5H1.5ZM39.5 77.5C18.5132 77.5 1.5 60.4868 1.5 39.5H-1.5C-1.5 62.1437 16.8563 80.5 39.5 80.5V77.5ZM51.4715 75.5763C47.7096 76.824 43.6853 77.5 39.5 77.5V80.5C44.0102 80.5 48.3532 79.7712 52.4159 78.4237L51.4715 75.5763ZM282 75.5H51.9437V78.5H282V75.5ZM280.5 22V77H283.5V22H280.5ZM262 3.5C272.217 3.5 280.5 11.7827 280.5 22H283.5C283.5 10.1259 273.874 0.5 262 0.5V3.5ZM51.9437 3.5H262V0.5H51.9437V3.5ZM39.5 1.5C43.6853 1.5 47.7096 2.17605 51.4715 3.42374L52.4159 0.576263C48.3532 -0.771182 44.0102 -1.5 39.5 -1.5V1.5Z"
          fill={active ? '#391363' : '#D8D8D8'}
          mask="url(#path-1-inside-1_920_6846)"
        />
        <rect x="214" y="52" width="50" height="14" rx="4" fill="#0C8CE9" />
        <rect x="89" y="58" width="65" height="8" rx="4" fill="#ACACAC" />
        <rect x="89" y="30" width="111.453" height="10" rx="4" fill="#ACACAC" />
        <rect x="89" y="13" width="175" height="10" rx="4" fill="#ACACAC" />
        <rect
          opacity="0.06"
          x="2"
          y="2"
          width="75"
          height="75"
          rx="37.5"
          fill="#0C8CE9"
        />
        <rect x="8" y="8" width="63" height="63" rx="31.5" fill="white" />
        <circle cx="39.5" cy="39.5" r="18.5" fill="#0C8CE9" />
      </svg>
    </button>
  );
};

export default Template5;
