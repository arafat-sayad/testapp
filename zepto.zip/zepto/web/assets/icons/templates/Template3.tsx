const Template3 = ({
  active,
  onClick,
}: {
  active?: boolean;
  onClick?: () => void;
}) => {
  return (
    <button onClick={onClick}>
      <svg
        width="280"
        height="75"
        viewBox="0 0 280 75"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <mask id="path-1-inside-1_920_6822" fill="white">
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M62.2754 75H242.5C263.21 75 280 58.2107 280 37.5C280 16.7893 263.21 0 242.5 0H62.2754C74.1894 8.20476 81.9997 21.9403 81.9997 37.5C81.9997 53.0597 74.1894 66.7952 62.2754 75Z"
          />
        </mask>
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M62.2754 75H242.5C263.21 75 280 58.2107 280 37.5C280 16.7893 263.21 0 242.5 0H62.2754C74.1894 8.20476 81.9997 21.9403 81.9997 37.5C81.9997 53.0597 74.1894 66.7952 62.2754 75Z"
          fill="white"
        />
        <path
          d="M62.2754 75L61.4246 73.7646L57.4526 76.5H62.2754V75ZM62.2754 0V-1.5H57.4526L61.4246 1.23539L62.2754 0ZM242.5 73.5H62.2754V76.5H242.5V73.5ZM278.5 37.5C278.5 57.3823 262.382 73.5 242.5 73.5V76.5C264.039 76.5 281.5 59.0391 281.5 37.5H278.5ZM242.5 1.5C262.382 1.5 278.5 17.6178 278.5 37.5H281.5C281.5 15.9609 264.039 -1.5 242.5 -1.5V1.5ZM62.2754 1.5H242.5V-1.5H62.2754V1.5ZM61.4246 1.23539C72.9496 9.17222 80.4997 22.4546 80.4997 37.5H83.4997C83.4997 21.426 75.4293 7.23731 63.1262 -1.23539L61.4246 1.23539ZM80.4997 37.5C80.4997 52.5454 72.9496 65.8278 61.4246 73.7646L63.1262 76.2354C75.4293 67.7627 83.4997 53.574 83.4997 37.5H80.4997Z"
          fill={active ? '#391363' : '#D8D8D8'}
          mask="url(#path-1-inside-1_920_6822)"
        />
        <rect
          x="0.75"
          y="0.75"
          width="73.5"
          height="73.5"
          rx="36.75"
          fill="white"
          stroke={active ? '#391363' : '#D8D8D8'}
          stroke-width="1.5"
        />
        <rect x="205" y="50" width="46" height="14" rx="4" fill="#F79722" />
        <rect x="91" y="56" width="59" height="8" rx="4" fill="#ACACAC" />
        <rect x="91" y="28" width="101.899" height="10" rx="4" fill="#ACACAC" />
        <rect x="91" y="11" width="160" height="10" rx="4" fill="#ACACAC" />
        <rect
          opacity="0.06"
          x="4"
          y="4"
          width="67"
          height="67"
          rx="33.5"
          fill="#F79722"
        />
        <circle cx="37.5" cy="37.5" r="18.5" fill="#F79722" />
      </svg>
    </button>
  );
};

export default Template3;
