const Template1 = ({
  active,
  onClick,
}: {
  active?: boolean;
  onClick?: () => void;
}) => {
  return (
    <button onClick={onClick}>
      <svg
        width="280"
        height="75"
        viewBox="0 0 280 75"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        // style={{
        //   borderRadius: '6px',
        //   boxShadow: '0px 0px 0px 2.5px #391363, 0px 0px 0px 1px #FFF',
        // }}
      >
        <rect
          x="0.75"
          y="0.75"
          width="278.5"
          height="73.5"
          rx="7.25"
          fill="white"
        />
        <rect
          x="0.75"
          y="0.75"
          width="278.5"
          height="73.5"
          rx="7.25"
          stroke={active ? '#391363' : '#D8D8D8'}
          stroke-width="1.5"
        />
        <rect x="219" y="50" width="50" height="14" rx="4" fill="#391363" />
        <rect x="73" y="56" width="76" height="8" rx="4" fill="#ACACAC" />
        <rect x="73" y="28" width="125" height="10" rx="4" fill="#ACACAC" />
        <rect x="73" y="11" width="196" height="10" rx="4" fill="#ACACAC" />
        <rect
          opacity="0.06"
          x="10"
          y="10"
          width="55"
          height="55"
          rx="8"
          fill="#391363"
        />
        <circle cx="37.5" cy="37.5" r="18.5" fill="#391363" />
      </svg>
    </button>
  );
};

export default Template1;
