const Template4 = ({
  active,
  onClick,
}: {
  active?: boolean;
  onClick?: () => void;
}) => {
  return (
    <button onClick={onClick}>
      <svg
        width="280"
        height="75"
        viewBox="0 0 280 75"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect
          x="0.75"
          y="0.75"
          width="278.5"
          height="73.5"
          rx="36.75"
          fill="white"
        />
        <rect
          x="0.75"
          y="0.75"
          width="278.5"
          height="73.5"
          rx="36.75"
          stroke={active ? '#391363' : '#D8D8D8'}
          stroke-width="1.5"
        />
        <rect x="197" y="50" width="49" height="14" rx="4" fill="#8A38F5" />
        <rect x="83" y="56" width="62" height="8" rx="4" fill="#ACACAC" />
        <rect x="83" y="28" width="103.81" height="10" rx="4" fill="#ACACAC" />
        <rect x="83" y="11" width="163" height="10" rx="4" fill="#ACACAC" />
        <rect
          opacity="0.06"
          x="4"
          y="4"
          width="67"
          height="67"
          rx="33.5"
          fill="#8A38F5"
        />
        <circle cx="37.5" cy="37.5" r="18.5" fill="#8A38F5" />
      </svg>
    </button>
  );
};

export default Template4;
