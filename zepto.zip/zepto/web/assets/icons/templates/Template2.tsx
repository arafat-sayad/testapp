const Template2 = ({
  active,
  onClick,
}: {
  active?: boolean;
  onClick?: () => void;
}) => {
  return (
    <button onClick={onClick}>
      <svg
        width="280"
        height="75"
        viewBox="0 0 280 75"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0.75 0.75H242.5C262.796 0.75 279.25 17.2035 279.25 37.5C279.25 57.7965 262.796 74.25 242.5 74.25H32C14.7411 74.25 0.75 60.2589 0.75 43V0.75Z"
          fill="white"
        />
        <path
          d="M0.75 0.75H242.5C262.796 0.75 279.25 17.2035 279.25 37.5C279.25 57.7965 262.796 74.25 242.5 74.25H32C14.7411 74.25 0.75 60.2589 0.75 43V0.75Z"
          stroke={active ? '#391363' : '#D8D8D8'}
          stroke-width="1.5"
        />
        <rect x="201" y="50" width="50" height="14" rx="4" fill="#E03E1A" />
        <rect x="73" y="56" width="64" height="8" rx="4" fill="#ACACAC" />
        <rect x="73" y="28" width="113.52" height="10" rx="4" fill="#ACACAC" />
        <rect x="73" y="11" width="178" height="10" rx="4" fill="#ACACAC" />
        <path
          opacity="0.06"
          d="M10 10H37.5C52.6878 10 65 22.3122 65 37.5C65 52.6878 52.6878 65 37.5 65C22.3122 65 10 52.6878 10 37.5V10Z"
          fill="#E03E1A"
        />
        <circle cx="37.5" cy="37.5" r="18.5" fill="#E03E1A" />
      </svg>
    </button>
  );
};

export default Template2;
