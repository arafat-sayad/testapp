interface VisitorIconProps {
  width?: string;
  height?: string;
  color?: string;
}

const VisitorIcon = ({
  width = '48',
  height = '48',
  color = '#391363',
}: VisitorIconProps) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 68 68"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        cx="57"
        cy="57"
        r="8"
        fill="#6FA07B"
        stroke="white"
        stroke-width="2"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M34 17.2C29.3608 17.2 25.6 20.9608 25.6 25.6C25.6 30.2391 29.3608 34 34 34C38.6392 34 42.4 30.2391 42.4 25.6C42.4 20.9608 38.6392 17.2 34 17.2ZM29.2 25.6C29.2 22.949 31.349 20.8 34 20.8C36.651 20.8 38.8 22.949 38.8 25.6C38.8 28.2509 36.651 30.4 34 30.4C31.349 30.4 29.2 28.2509 29.2 25.6Z"
        fill={color}
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M47.1615 44.1442C44.506 39.3644 39.4679 36.4 34 36.4C28.5321 36.4 23.4939 39.3644 20.8385 44.1442L19.7905 46.0306C18.6017 48.1704 20.149 50.8 22.5968 50.8H45.4032C47.851 50.8 49.3982 48.1704 48.2095 46.0306L47.1615 44.1442ZM23.9855 45.8925C26.006 42.2556 29.8395 40 34 40C38.1605 40 41.994 42.2556 44.0145 45.8925L44.7409 47.2H23.2591L23.9855 45.8925Z"
        fill={color}
      />
    </svg>
  );
};

export default VisitorIcon;
