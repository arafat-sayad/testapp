import { templateColors } from '@constants/index';
import {
  DefaultSettingsProps,
  MobilePosition,
  PositionProps,
  CampaignCustomizeInterface as Types,
} from '@type/index';
import { useCallback, useMemo, useState } from 'react';

interface Props {
  defaultSettings: DefaultSettingsProps;
}

const useCampaignCustomize = ({ defaultSettings }: Props) => {
  const [view, setView] = useState<Types['view']>('desktop');
  const toggleView = useCallback((view: Types['view']) => {
    setView(view);
  }, []);

  const [displaySettings, setDisplayValue] = useState<Types['displaySettings']>(
    defaultSettings.displaySettings
  );

  const handleDisplayChange = useCallback(
    (newValue: string | string[], key: string) => {
      setDisplayValue((prev) => ({ ...prev, [key]: newValue }));
    },
    []
  );

  const [content, setContent] = useState<Types['content']>(
    defaultSettings.content
  );

  const handleContentChange = useCallback((value: string) => {
    setContent(value);
  }, []);

  const [activeMobile, setActiveMobile] = useState(
    defaultSettings.activeMobile
  );

  const toggleActiveMobile = useCallback(() => {
    setActiveMobile((prev) => !prev);
  }, []);

  const [desktopPosition, setDesktopPosition] = useState<
    Types['desktopPosition']
  >(defaultSettings.desktopPosition);

  const toggleDesktopPosition = useCallback(
    (position: PositionProps['position']) => {
      setDesktopPosition(position);
    },
    []
  );

  const [mobilePosition, setMobilePosition] = useState<Types['mobilePosition']>(
    defaultSettings.mobilePosition
  );
  const toggleMobilePosition = useCallback(
    (position: MobilePosition['position']) => {
      setMobilePosition(position);
    },
    []
  );

  const [colors, setColors] = useState(defaultSettings.colors);

  const [activeTemplate, setActiveTemplate] = useState<Types['activeTemplate']>(
    defaultSettings.activeTemplate
  );

  const handleHexChange = useCallback(
    (key: 'background' | 'content' | 'time' | 'action', value: string) => {
      setColors((prevState) => ({ ...prevState, [key]: value }));
    },
    []
  );

  const handleActiveChange = useCallback((value: Types['activeTemplate']) => {
    setActiveTemplate(value);
    setColors(templateColors[value]);
  }, []);

  const values = useMemo(
    () => ({
      view,
      content,
      handleContentChange,
      toggleView,
      desktopPosition,
      mobilePosition,
      toggleDesktopPosition,
      toggleMobilePosition,
      activeMobile,
      toggleActiveMobile,
      colors,
      activeTemplate,
      handleHexChange,
      handleActiveChange,
      displaySettings,
      handleDisplayChange,
    }),
    [
      displaySettings,
      handleDisplayChange,
      view,
      toggleView,
      content,
      handleContentChange,
      desktopPosition,
      mobilePosition,
      toggleDesktopPosition,
      toggleMobilePosition,
      activeMobile,
      toggleActiveMobile,
      colors,
      activeTemplate,
      handleHexChange,
      handleActiveChange,
    ]
  );

  return values;
};

export default useCampaignCustomize;
